# Keep Razorpay classes
-keep class com.razorpay.** { *; }
-keepattributes *Annotation*
-dontwarn com.razorpay.**

# Keep Room database
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# Keep Kotlin coroutines
-keepclassmembernames class kotlinx.** { volatile <fields>; }

# Keep game classes
-keep class com.crystalshadow.runner.** { *; }

# Google Pay (used by Razorpay internally)
-keep class com.google.android.apps.nbu.paisa.inapp.client.api.** { *; }
