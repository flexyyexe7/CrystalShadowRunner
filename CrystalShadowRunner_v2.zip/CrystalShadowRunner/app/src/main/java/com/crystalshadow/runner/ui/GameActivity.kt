package com.crystalshadow.runner.ui

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.crystalshadow.runner.R
import com.crystalshadow.runner.data.PlayerDataManager
import com.crystalshadow.runner.game.GameView
import com.crystalshadow.runner.game.Player
import com.crystalshadow.runner.utils.SoundManager

class GameActivity : AppCompatActivity() {

    private lateinit var gameView: GameView
    private lateinit var tvScore: TextView
    private lateinit var tvCrystals: TextView
    private lateinit var tvPowerUp: TextView
    private lateinit var btnPause: ImageButton
    private lateinit var pausePanel: View

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        setContentView(R.layout.activity_game)

        gameView = GameView(this)
        val gameContainer = findViewById<FrameLayout>(R.id.gameContainer)
        gameContainer.addView(gameView, 0)

        tvScore    = findViewById(R.id.tvScore)
        tvCrystals = findViewById(R.id.tvCrystals)
        tvPowerUp  = findViewById(R.id.tvPowerUp)
        btnPause   = findViewById(R.id.btnPause)
        pausePanel = findViewById(R.id.pausePanel)

        setupGameCallbacks()
        setupPauseButton()
        setupPausePanel()

        SoundManager.startBackgroundMusic(this)
    }

    private fun setupGameCallbacks() {
        gameView.onScoreUpdated = { score ->
            runOnUiThread { tvScore.text = "Score: $score" }
        }

        gameView.onCrystalUpdated = { crystals ->
            runOnUiThread { tvCrystals.text = "💎 $crystals" }
        }

        gameView.onPowerUpActivated = { type ->
            runOnUiThread {
                val name = when (type) {
                    Player.PowerUpType.LIGHTNING_DASH -> "⚡ Lightning Dash!"
                    Player.PowerUpType.SHIELD_PROTECTION -> "🛡 Shield Active!"
                    Player.PowerUpType.FIRE_TRAIL -> "🔥 Fire Trail!"
                    Player.PowerUpType.SHADOW_TELEPORT -> "👻 Shadow Teleport!"
                }
                tvPowerUp.text = name
                tvPowerUp.visibility = View.VISIBLE
                tvPowerUp.postDelayed({ tvPowerUp.visibility = View.GONE }, 2500)
            }
        }

        gameView.onGameOver = { score, crystals ->
            // Save data
            PlayerDataManager.submitScore(score)
            PlayerDataManager.addCrystals(crystals)

            runOnUiThread {
                val intent = Intent(this, GameOverActivity::class.java).apply {
                    putExtra("SCORE", score)
                    putExtra("CRYSTALS", crystals)
                    putExtra("HIGH_SCORE", PlayerDataManager.getHighScore())
                }
                startActivity(intent)
                overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
                finish()
            }
        }
    }

    private fun setupPauseButton() {
        btnPause.setOnClickListener {
            if (pausePanel.visibility == View.GONE) {
                gameView.pauseGame()
                pausePanel.visibility = View.VISIBLE
                SoundManager.pauseMusic()
            }
        }
    }

    private fun setupPausePanel() {
        findViewById<View>(R.id.btnResume).setOnClickListener {
            pausePanel.visibility = View.GONE
            gameView.resumeGame()
            SoundManager.resumeMusic()
        }

        findViewById<View>(R.id.btnQuitGame).setOnClickListener {
            SoundManager.stopMusic()
            finish()
        }
    }

    override fun onPause() {
        super.onPause()
        gameView.pauseGame()
        SoundManager.pauseMusic()
    }

    override fun onResume() {
        super.onResume()
        if (pausePanel.visibility == View.GONE) {
            gameView.resumeGame()
        }
    }

    override fun onBackPressed() {
        if (pausePanel.visibility == View.VISIBLE) {
            pausePanel.visibility = View.GONE
            gameView.resumeGame()
        } else {
            gameView.pauseGame()
            pausePanel.visibility = View.VISIBLE
        }
    }
}
