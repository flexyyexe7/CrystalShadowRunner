package com.crystalshadow.runner.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.crystalshadow.runner.R
import com.crystalshadow.runner.data.AppDatabase
import com.crystalshadow.runner.data.LeaderboardEntry
import com.crystalshadow.runner.data.PlayerDataManager
import com.crystalshadow.runner.utils.SoundManager
import kotlinx.coroutines.launch

class LeaderboardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        setContentView(R.layout.activity_leaderboard)

        // Save current score to leaderboard on view
        lifecycleScope.launch {
            val db = AppDatabase.getInstance(applicationContext)
            val highScore = PlayerDataManager.getHighScore()
            if (highScore > 0) {
                db.leaderboardDao().insert(
                    LeaderboardEntry(
                        playerName = PlayerDataManager.getPlayerName(),
                        score = highScore,
                        crystalsCollected = PlayerDataManager.getCrystals()
                    )
                )
                db.leaderboardDao().pruneOldEntries()
            }
            val entries = db.leaderboardDao().getTopScores(20)
            runOnUiThread { setupList(entries) }
        }

        // Player stats
        findViewById<TextView>(R.id.tvMyScore).text =
            "Your Best: ${PlayerDataManager.getHighScore()}"
        findViewById<TextView>(R.id.tvGamesPlayed).text =
            "Games: ${PlayerDataManager.getGamesPlayed()}"

        findViewById<View>(R.id.btnBack).setOnClickListener {
            SoundManager.playClick(); finish()
        }
    }

    private fun setupList(entries: List<LeaderboardEntry>) {
        val rv = findViewById<RecyclerView>(R.id.rvLeaderboard)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = LeaderboardAdapter(entries)
    }
}

class LeaderboardAdapter(private val entries: List<LeaderboardEntry>) :
    RecyclerView.Adapter<LeaderboardAdapter.VH>() {

    inner class VH(v: View) : RecyclerView.ViewHolder(v) {
        val tvRank  : TextView = v.findViewById(R.id.tvRank)
        val tvName  : TextView = v.findViewById(R.id.tvPlayerName)
        val tvScore : TextView = v.findViewById(R.id.tvScore)
        val tvMedal : TextView = v.findViewById(R.id.tvMedal)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(LayoutInflater.from(parent.context).inflate(R.layout.item_leaderboard, parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) {
        val e = entries[position]
        holder.tvRank.text  = "#${position + 1}"
        holder.tvName.text  = e.playerName
        holder.tvScore.text = "${e.score}"
        holder.tvMedal.text = when (position) { 0 -> "🥇"; 1 -> "🥈"; 2 -> "🥉"; else -> "🏅" }
    }

    override fun getItemCount() = entries.size
}
