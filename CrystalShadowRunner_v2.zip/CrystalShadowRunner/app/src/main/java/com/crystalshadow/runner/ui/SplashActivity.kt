package com.crystalshadow.runner.ui

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.view.animation.AlphaAnimation
import android.view.animation.Animation
import android.widget.FrameLayout
import androidx.appcompat.app.AppCompatActivity
import com.crystalshadow.runner.data.PlayerDataManager
import com.crystalshadow.runner.payment.RazorpayManager
import com.crystalshadow.runner.utils.NeonPaint
import com.crystalshadow.runner.utils.ParticleSystem

@SuppressLint("CustomSplashScreen")
class SplashActivity : AppCompatActivity() {

    private lateinit var splashView: SplashView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )

        splashView = SplashView(this)
        setContentView(splashView)

        // Pre-load Razorpay SDK during splash
        RazorpayManager.preload(this)

        // Navigate to main menu after 2.5 seconds
        Handler(Looper.getMainLooper()).postDelayed({
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)

            // Show daily reward if available
            if (PlayerDataManager.canClaimDailyReward()) {
                startActivity(Intent(this, DailyRewardActivity::class.java))
            }

            finish()
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }, 2500)
    }
}

/** Custom animated splash screen drawn on Canvas */
class SplashView(context: android.content.Context) : View(context) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val particles = ParticleSystem()
    private var tick = 0f
    private val handler = Handler(Looper.getMainLooper())

    private val runnable = object : Runnable {
        override fun run() {
            tick++
            particles.emitAmbientDust(width.toFloat(), height.toFloat())
            particles.emitCrystalSparkle(
                width * 0.5f + (Math.sin(tick * 0.03) * 30f).toFloat(),
                height * 0.42f
            )
            particles.update()
            invalidate()
            handler.postDelayed(this, 16)
        }
    }

    init { handler.post(runnable) }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()

        // Background gradient
        NeonPaint.drawBackground(canvas, w, h, NeonPaint.Environment.CYBER_NEON)

        // Particles
        particles.draw(canvas)

        // Pulsing glow behind title
        val pulse = (Math.sin(tick * 0.05) * 0.5 + 0.5).toFloat()
        paint.style = Paint.Style.FILL
        paint.color = Color.parseColor("#00FFFF")
        paint.alpha = (30 + pulse * 40f).toInt()
        paint.maskFilter = BlurMaskFilter(120f, BlurMaskFilter.Blur.NORMAL)
        canvas.drawCircle(w / 2f, h * 0.42f, 160f + pulse * 30f, paint)
        paint.maskFilter = null

        // Crystal logo icon
        NeonPaint.drawCrystal(canvas, w / 2f, h * 0.32f, 55f + pulse * 8f)

        // Title: CRYSTAL SHADOW RUNNER
        NeonPaint.drawNeonText(
            canvas, "CRYSTAL SHADOW",
            w / 2f, h * 0.52f,
            Color.WHITE, Color.parseColor("#00FFFF"),
            w * 0.065f, 18f
        )
        NeonPaint.drawNeonText(
            canvas, "RUNNER",
            w / 2f, h * 0.60f,
            Color.parseColor("#00FFFF"), Color.parseColor("#7C4DFF"),
            w * 0.12f, 25f
        )

        // Loading bar
        val barW = w * 0.6f
        val barX = (w - barW) / 2f
        val barY = h * 0.78f
        val progress = ((tick % 120f) / 120f).coerceIn(0f, 1f)

        paint.alpha = 80
        paint.color = Color.parseColor("#1A1A2E")
        canvas.drawRoundRect(RectF(barX, barY, barX + barW, barY + 8f), 4f, 4f, paint)

        paint.alpha = 255
        val shader = LinearGradient(
            barX, barY, barX + barW * progress, barY,
            Color.parseColor("#00FFFF"), Color.parseColor("#7C4DFF"),
            Shader.TileMode.CLAMP
        )
        paint.shader = shader
        canvas.drawRoundRect(RectF(barX, barY, barX + barW * progress, barY + 8f), 4f, 4f, paint)
        paint.shader = null

        NeonPaint.drawNeonText(
            canvas, "Loading...",
            w / 2f, barY + 35f,
            Color.parseColor("#80DEEA"), Color.parseColor("#00BCD4"),
            28f, 6f
        )

        // Version
        paint.color = Color.WHITE
        paint.alpha = 60
        paint.textSize = 22f
        paint.textAlign = Paint.Align.CENTER
        canvas.drawText("v1.0.0", w / 2f, h * 0.93f, paint)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        handler.removeCallbacks(runnable)
    }
}
