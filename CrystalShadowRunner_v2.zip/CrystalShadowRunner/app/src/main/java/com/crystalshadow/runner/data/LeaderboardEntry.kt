package com.crystalshadow.runner.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Local leaderboard entry stored in Room database.
 */
@Entity(tableName = "leaderboard")
data class LeaderboardEntry(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val playerName: String,
    val score: Int,
    val crystalsCollected: Int,
    val timestamp: Long = System.currentTimeMillis()
)
