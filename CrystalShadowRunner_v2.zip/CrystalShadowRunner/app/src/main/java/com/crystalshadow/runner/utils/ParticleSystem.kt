package com.crystalshadow.runner.utils

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import kotlin.math.cos
import kotlin.math.sin
import kotlin.random.Random

/**
 * Lightweight particle system for neon visual effects.
 * Handles crystal sparkles, power-up bursts, trail effects, and explosions.
 */
class ParticleSystem {

    private val particles = mutableListOf<Particle>()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    // ─── Emission Methods ─────────────────────────────────────────

    /** Emit a burst of crystal sparkles */
    fun emitCrystalSparkle(x: Float, y: Float) {
        repeat(12) {
            val angle = (it * 30f) * Math.PI.toFloat() / 180f
            val speed = Random.nextFloat() * 4f + 2f
            particles.add(Particle(
                x = x, y = y,
                vx = cos(angle) * speed,
                vy = sin(angle) * speed,
                life = 1f,
                color = CYAN_COLORS.random(),
                size = Random.nextFloat() * 6f + 2f,
                gravity = 0.1f,
                fadeRate = 0.04f
            ))
        }
    }

    /** Emit fire trail particles behind the player */
    fun emitFireTrail(x: Float, y: Float) {
        repeat(3) {
            particles.add(Particle(
                x = x + Random.nextFloat() * 10f - 5f,
                y = y + Random.nextFloat() * 10f - 5f,
                vx = Random.nextFloat() * -3f - 1f,
                vy = Random.nextFloat() * -2f - 0.5f,
                life = 1f,
                color = FIRE_COLORS.random(),
                size = Random.nextFloat() * 10f + 4f,
                gravity = -0.05f,
                fadeRate = 0.06f
            ))
        }
    }

    /** Emit lightning dash effect */
    fun emitLightningDash(x: Float, y: Float) {
        repeat(20) {
            val angle = Random.nextFloat() * 360f * Math.PI.toFloat() / 180f
            val speed = Random.nextFloat() * 8f + 4f
            particles.add(Particle(
                x = x, y = y,
                vx = cos(angle) * speed,
                vy = sin(angle) * speed,
                life = 1f,
                color = LIGHTNING_COLORS.random(),
                size = Random.nextFloat() * 4f + 1f,
                gravity = 0f,
                fadeRate = 0.08f
            ))
        }
    }

    /** Emit shield impact effect */
    fun emitShieldHit(x: Float, y: Float) {
        repeat(15) {
            val angle = Random.nextFloat() * 360f * Math.PI.toFloat() / 180f
            val speed = Random.nextFloat() * 5f + 2f
            particles.add(Particle(
                x = x, y = y,
                vx = cos(angle) * speed,
                vy = sin(angle) * speed,
                life = 1f,
                color = SHIELD_COLORS.random(),
                size = Random.nextFloat() * 8f + 2f,
                gravity = 0.05f,
                fadeRate = 0.05f
            ))
        }
    }

    /** Emit shadow teleport dissolve effect */
    fun emitShadowTeleport(x: Float, y: Float) {
        repeat(25) {
            val angle = Random.nextFloat() * 360f * Math.PI.toFloat() / 180f
            val speed = Random.nextFloat() * 6f + 1f
            particles.add(Particle(
                x = x + Random.nextFloat() * 40f - 20f,
                y = y + Random.nextFloat() * 60f - 30f,
                vx = cos(angle) * speed,
                vy = sin(angle) * speed,
                life = 1f,
                color = SHADOW_COLORS.random(),
                size = Random.nextFloat() * 12f + 3f,
                gravity = 0f,
                fadeRate = 0.04f
            ))
        }
    }

    /** Emit explosion on death */
    fun emitDeathExplosion(x: Float, y: Float) {
        repeat(40) {
            val angle = Random.nextFloat() * 360f * Math.PI.toFloat() / 180f
            val speed = Random.nextFloat() * 10f + 2f
            particles.add(Particle(
                x = x, y = y,
                vx = cos(angle) * speed,
                vy = sin(angle) * speed,
                life = 1f,
                color = FIRE_COLORS.random(),
                size = Random.nextFloat() * 14f + 4f,
                gravity = 0.2f,
                fadeRate = 0.025f
            ))
        }
    }

    /** Emit ambient background dust */
    fun emitAmbientDust(screenWidth: Float, screenHeight: Float) {
        if (particles.size < 30 && Random.nextFloat() < 0.3f) {
            particles.add(Particle(
                x = Random.nextFloat() * screenWidth,
                y = Random.nextFloat() * screenHeight,
                vx = Random.nextFloat() * -1f - 0.3f,
                vy = Random.nextFloat() * 0.5f - 0.25f,
                life = 0.6f,
                color = AMBIENT_COLORS.random(),
                size = Random.nextFloat() * 3f + 1f,
                gravity = 0f,
                fadeRate = 0.008f
            ))
        }
    }

    // ─── Update & Draw ────────────────────────────────────────────

    fun update() {
        val iter = particles.iterator()
        while (iter.hasNext()) {
            val p = iter.next()
            p.x += p.vx
            p.y += p.vy
            p.vy += p.gravity
            p.vx *= 0.98f
            p.life -= p.fadeRate
            p.size *= 0.97f
            if (p.life <= 0f || p.size < 0.5f) iter.remove()
        }
    }

    fun draw(canvas: Canvas) {
        for (p in particles) {
            val alpha = (p.life * 255).toInt().coerceIn(0, 255)
            paint.color = p.color
            paint.alpha = alpha
            paint.style = Paint.Style.FILL
            canvas.drawCircle(p.x, p.y, p.size, paint)

            // Glow effect — draw larger, semi-transparent circle
            paint.alpha = alpha / 4
            canvas.drawCircle(p.x, p.y, p.size * 2f, paint)
        }
    }

    fun clear() = particles.clear()

    // ─── Color Palettes ───────────────────────────────────────────

    companion object {
        val CYAN_COLORS = listOf(
            Color.parseColor("#00FFFF"),
            Color.parseColor("#00E5FF"),
            Color.parseColor("#80FFFF"),
            Color.parseColor("#00BCD4")
        )
        val FIRE_COLORS = listOf(
            Color.parseColor("#FF6B00"),
            Color.parseColor("#FF9800"),
            Color.parseColor("#FFEB3B"),
            Color.parseColor("#FF4444")
        )
        val LIGHTNING_COLORS = listOf(
            Color.parseColor("#FFFF00"),
            Color.parseColor("#FFD700"),
            Color.parseColor("#FFFFFF"),
            Color.parseColor("#FFF176")
        )
        val SHIELD_COLORS = listOf(
            Color.parseColor("#4FC3F7"),
            Color.parseColor("#29B6F6"),
            Color.parseColor("#81D4FA"),
            Color.parseColor("#FFFFFF")
        )
        val SHADOW_COLORS = listOf(
            Color.parseColor("#7B1FA2"),
            Color.parseColor("#9C27B0"),
            Color.parseColor("#CE93D8"),
            Color.parseColor("#E040FB")
        )
        val AMBIENT_COLORS = listOf(
            Color.parseColor("#1A237E"),
            Color.parseColor("#283593"),
            Color.parseColor("#7986CB"),
            Color.parseColor("#3949AB")
        )
    }
}

/** Individual particle data class */
data class Particle(
    var x: Float,
    var y: Float,
    var vx: Float,
    var vy: Float,
    var life: Float,
    var color: Int,
    var size: Float,
    var gravity: Float,
    var fadeRate: Float
)
