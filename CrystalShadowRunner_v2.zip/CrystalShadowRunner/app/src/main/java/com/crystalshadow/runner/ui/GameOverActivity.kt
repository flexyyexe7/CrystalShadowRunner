package com.crystalshadow.runner.ui

import android.content.Intent
import android.os.Bundle
import android.view.WindowManager
import android.widget.TextView
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.crystalshadow.runner.R
import com.crystalshadow.runner.data.PlayerDataManager
import com.crystalshadow.runner.store.StoreActivity
import com.crystalshadow.runner.utils.SoundManager

class GameOverActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        setContentView(R.layout.activity_game_over)

        val score     = intent.getIntExtra("SCORE", 0)
        val crystals  = intent.getIntExtra("CRYSTALS", 0)
        val highScore = intent.getIntExtra("HIGH_SCORE", 0)

        findViewById<TextView>(R.id.tvFinalScore).text  = "Score: $score"
        findViewById<TextView>(R.id.tvHighScore).text   = "Best: $highScore"
        findViewById<TextView>(R.id.tvCrystalsEarned).text = "+$crystals 💎"
        findViewById<TextView>(R.id.tvTotalCrystals).text  =
            "Total: ${PlayerDataManager.getCrystals()} 💎"

        val isNewBest = score >= highScore
        findViewById<TextView>(R.id.tvNewRecord).visibility =
            if (isNewBest) View.VISIBLE else View.GONE

        findViewById<View>(R.id.btnPlayAgain).setOnClickListener {
            SoundManager.playClick()
            startActivity(Intent(this, GameActivity::class.java))
            finish()
        }

        findViewById<View>(R.id.btnMainMenu).setOnClickListener {
            SoundManager.playClick()
            startActivity(Intent(this, MainActivity::class.java))
            finishAffinity()
        }

        findViewById<View>(R.id.btnStore).setOnClickListener {
            SoundManager.playClick()
            startActivity(Intent(this, StoreActivity::class.java))
        }
    }
}
