package com.crystalshadow.runner.game

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.crystalshadow.runner.AppConfig
import com.crystalshadow.runner.utils.NeonPaint
import com.crystalshadow.runner.utils.ParticleSystem
import com.crystalshadow.runner.utils.SoundManager
import kotlin.math.min
import kotlin.random.Random

/**
 * Core game engine — manages the world, spawning, physics, and game state.
 * This is the brain of the entire game.
 */
class GameEngine(
    private val context: Context,
    val screenWidth: Float,
    val screenHeight: Float
) {
    // ─── Game State ───────────────────────────────────────────────

    enum class State { RUNNING, PAUSED, GAME_OVER }
    var state = State.RUNNING
        private set

    // ─── World ────────────────────────────────────────────────────

    val player = Player(screenWidth, screenHeight)
    private val obstacles = mutableListOf<Obstacle>()
    private val crystals = mutableListOf<Crystal>()
    private val powerUps = mutableListOf<PowerUpItem>()
    private val enemies = mutableListOf<Enemy>()
    private val backgroundParticles = ParticleSystem()

    // ─── Score & Currency ─────────────────────────────────────────

    var score = 0
    var crystalCount = 0
    private var scoreAccumulator = 0f

    // ─── Speed ────────────────────────────────────────────────────

    var currentSpeed = AppConfig.GAME_SPEED_INITIAL
        private set

    // ─── Environment ──────────────────────────────────────────────

    private var environment = NeonPaint.Environment.CITY
    private var environmentChangeScore = 0

    // ─── Spawning ─────────────────────────────────────────────────

    private var tickCount = 0
    private var lastObstacleX = screenWidth
    private var minObstaceSpacing = 400f

    // ─── Ground Level ─────────────────────────────────────────────

    val groundY = screenHeight * 0.75f

    // ─── Background Layers (parallax) ─────────────────────────────

    private val bgLayer1 = mutableListOf<BgElement>()   // Distant buildings
    private val bgLayer2 = mutableListOf<BgElement>()   // Mid buildings
    private val bgLayer3 = mutableListOf<BgElement>()   // Ground detail

    // ─── Callbacks ────────────────────────────────────────────────

    var onGameOver: ((score: Int, crystals: Int) -> Unit)? = null
    var onCrystalCollected: ((total: Int) -> Unit)? = null
    var onScoreUpdated: ((score: Int) -> Unit)? = null
    var onPowerUpActivated: ((type: Player.PowerUpType) -> Unit)? = null

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    // ─────────────────────────────────────────────────────────────

    init {
        generateInitialBackground()
    }

    // ─── Public Controls ──────────────────────────────────────────

    fun jump() {
        if (state == State.RUNNING) player.jump()
    }

    fun slide() {
        if (state == State.RUNNING) player.startSlide()
    }

    fun dash() {
        if (state == State.RUNNING) player.startDash()
    }

    fun pause() {
        state = State.PAUSED
        SoundManager.pauseMusic()
    }

    fun resume() {
        state = State.RUNNING
        SoundManager.resumeMusic()
    }

    // ─── Main Update Loop ─────────────────────────────────────────

    fun update() {
        if (state != State.RUNNING) return

        tickCount++

        // ── Speed increase over time ───────────────────────────────
        if (currentSpeed < AppConfig.GAME_SPEED_MAX) {
            currentSpeed += AppConfig.GAME_SPEED_INCREMENT
        }

        // ── Score ─────────────────────────────────────────────────
        scoreAccumulator += currentSpeed * 0.05f
        if (scoreAccumulator >= 1f) {
            score += scoreAccumulator.toInt()
            scoreAccumulator -= scoreAccumulator.toInt()
            onScoreUpdated?.invoke(score)
        }

        // ── Environment changes ───────────────────────────────────
        if (score > environmentChangeScore + 500) {
            environmentChangeScore = score
            environment = NeonPaint.Environment.entries.random()
        }

        // ── Player update ─────────────────────────────────────────
        player.update(currentSpeed)

        // ── Spawning ──────────────────────────────────────────────
        spawnObjects()

        // ── Update all game objects ───────────────────────────────
        obstacles.forEach { it.update(currentSpeed) }
        crystals.forEach { it.update(currentSpeed) }
        powerUps.forEach { it.update(currentSpeed) }
        enemies.forEach { it.update(currentSpeed) }

        // ── Collision detection ───────────────────────────────────
        handleCollisions()

        // ── Remove inactive objects ───────────────────────────────
        obstacles.removeAll { !it.active }
        crystals.removeAll { !it.active }
        powerUps.removeAll { !it.active }
        enemies.removeAll { !it.active }

        // ── Parallax background ───────────────────────────────────
        updateBackground()

        // ── Ambient particles ─────────────────────────────────────
        backgroundParticles.emitAmbientDust(screenWidth, screenHeight)
        backgroundParticles.update()

        // ── Check game over ───────────────────────────────────────
        if (!player.isAlive) {
            state = State.GAME_OVER
            onGameOver?.invoke(score, crystalCount)
        }
    }

    // ─── Rendering ───────────────────────────────────────────────

    fun draw(canvas: Canvas) {
        // Background
        NeonPaint.drawBackground(canvas, screenWidth, screenHeight, environment)

        // Ambient particles
        backgroundParticles.draw(canvas)

        // Parallax layers
        drawBackground(canvas)

        // Ground
        drawGround(canvas)

        // Game objects
        crystals.forEach { it.draw(canvas, paint, tickCount) }
        powerUps.forEach { it.draw(canvas, paint, tickCount) }
        obstacles.forEach { it.draw(canvas, paint, tickCount) }
        enemies.forEach { it.draw(canvas, paint, tickCount) }

        // Player on top
        player.draw(canvas)
    }

    // ─── Collision Detection ──────────────────────────────────────

    private fun handleCollisions() {
        if (AppConfig.DEBUG_GOD_MODE) return

        val playerHitbox = player.hitbox

        // Crystals
        crystals.filter { it.active && RectF.intersects(playerHitbox, it.hitbox) }.forEach {
            it.active = false
            crystalCount++
            onCrystalCollected?.invoke(crystalCount)
            SoundManager.playCrystalCollect()
        }

        // Power-ups
        powerUps.filter { it.active && RectF.intersects(playerHitbox, it.hitbox) }.forEach {
            it.active = false
            player.activatePowerUp(it.type)
            onPowerUpActivated?.invoke(it.type)
        }

        // Obstacles
        if (!player.isInvincible) {
            obstacles.filter { it.active && RectF.intersects(playerHitbox, it.hitbox) }.forEach {
                killPlayer()
                return
            }

            // Enemies
            enemies.filter { it.active && !it.isDead && RectF.intersects(playerHitbox, it.hitbox) }.forEach {
                if (player.activePowerUp == Player.PowerUpType.LIGHTNING_DASH ||
                    player.activePowerUp == Player.PowerUpType.FIRE_TRAIL) {
                    it.hit()
                    it.hit()
                } else {
                    killPlayer()
                    return
                }
            }
        }
    }

    private fun killPlayer() {
        if (AppConfig.DEBUG_GOD_MODE) return
        player.die()
        SoundManager.playGameOver()
    }

    // ─── Spawning Logic ───────────────────────────────────────────

    private fun spawnObjects() {
        val spawnX = screenWidth + 50f

        // Spawn crystals frequently
        if (tickCount % 40 == 0) {
            val numCrystals = Random.nextInt(1, 5)
            for (i in 0 until numCrystals) {
                crystals.add(Crystal(
                    x = spawnX + i * 35f,
                    y = groundY - Random.nextFloat() * 200f - 30f
                ))
            }
        }

        // Spawn obstacles
        val minSpacing = (minObstaceSpacing - currentSpeed * 5f).coerceAtLeast(250f)
        if (spawnX - lastObstacleX > minSpacing && tickCount > 120) {
            spawnObstacle(spawnX)
            lastObstacleX = spawnX
        }

        // Spawn power-ups occasionally
        if (tickCount % 300 == 0) {
            powerUps.add(PowerUpItem(
                x = spawnX,
                y = groundY - 120f,
                type = Player.PowerUpType.entries.random()
            ))
        }

        // Spawn enemies
        if (tickCount % 180 == 0 && score > 200) {
            enemies.add(Enemy(
                x = spawnX,
                y = if (Random.nextBoolean()) groundY - 65f else groundY - 140f,
                type = Enemy.EnemyType.entries.random()
            ))
        }
    }

    private fun spawnObstacle(x: Float) {
        val obstacleTypes = mutableListOf(
            Obstacle.ObstacleType.GROUND_SPIKE,
            Obstacle.ObstacleType.TALL_WALL
        )
        if (score > 300) obstacleTypes.add(Obstacle.ObstacleType.ELECTRIC_GATE)
        if (score > 600) obstacleTypes.add(Obstacle.ObstacleType.LASER_BEAM)

        val type = obstacleTypes.random()
        val (obsWidth, obsHeight) = when (type) {
            Obstacle.ObstacleType.GROUND_SPIKE -> Pair(40f + Random.nextFloat() * 40f, 40f)
            Obstacle.ObstacleType.TALL_WALL -> Pair(25f, 80f + Random.nextFloat() * 80f)
            Obstacle.ObstacleType.FLOATING_PLATFORM -> Pair(100f, 20f)
            Obstacle.ObstacleType.ELECTRIC_GATE -> Pair(80f, groundY * 0.5f)
            Obstacle.ObstacleType.LASER_BEAM -> Pair(screenWidth * 0.15f, 12f)
        }
        val obsY = when (type) {
            Obstacle.ObstacleType.FLOATING_PLATFORM -> groundY - 160f
            Obstacle.ObstacleType.ELECTRIC_GATE -> groundY - obsHeight
            Obstacle.ObstacleType.LASER_BEAM -> groundY - Random.nextFloat() * 150f - 30f
            else -> groundY - obsHeight
        }

        obstacles.add(Obstacle(x, obsY, obsWidth, obsHeight, type, environment))
    }

    // ─── Background & Parallax ────────────────────────────────────

    private fun generateInitialBackground() {
        // Layer 1 — distant city buildings
        for (i in 0..12) {
            bgLayer1.add(BgElement(
                x = i * (screenWidth / 8f),
                y = 0f,
                width = 40f + Random.nextFloat() * 60f,
                height = screenHeight * 0.2f + Random.nextFloat() * screenHeight * 0.3f
            ))
        }
        // Layer 2 — mid buildings
        for (i in 0..16) {
            bgLayer2.add(BgElement(
                x = i * (screenWidth / 10f),
                y = 0f,
                width = 30f + Random.nextFloat() * 50f,
                height = screenHeight * 0.15f + Random.nextFloat() * screenHeight * 0.25f
            ))
        }
    }

    private fun updateBackground() {
        bgLayer1.forEach { it.x -= currentSpeed * 0.2f }
        bgLayer2.forEach { it.x -= currentSpeed * 0.4f }

        // Wrap around
        bgLayer1.filter { it.x + it.width < 0f }.forEach {
            it.x = screenWidth + Random.nextFloat() * 100f
            it.height = screenHeight * 0.2f + Random.nextFloat() * screenHeight * 0.3f
        }
        bgLayer2.filter { it.x + it.width < 0f }.forEach {
            it.x = screenWidth + Random.nextFloat() * 60f
            it.height = screenHeight * 0.15f + Random.nextFloat() * screenHeight * 0.25f
        }
    }

    private fun drawBackground(canvas: Canvas) {
        // Layer 1 — far buildings
        val farColor = when (environment) {
            NeonPaint.Environment.CITY -> Color.parseColor("#0D47A1")
            NeonPaint.Environment.JUNGLE -> Color.parseColor("#1B5E20")
            NeonPaint.Environment.CYBER_NEON -> Color.parseColor("#1A0030")
        }
        paint.color = farColor
        paint.alpha = 120
        paint.style = Paint.Style.FILL
        bgLayer1.forEach { canvas.drawRect(it.x, groundY - it.height, it.x + it.width, groundY, paint) }

        // Accent lines on buildings
        val accentColor = when (environment) {
            NeonPaint.Environment.CITY -> Color.parseColor("#1565C0")
            NeonPaint.Environment.JUNGLE -> Color.parseColor("#388E3C")
            NeonPaint.Environment.CYBER_NEON -> Color.parseColor("#7B1FA2")
        }
        paint.color = accentColor
        paint.alpha = 60
        bgLayer2.forEach { canvas.drawRect(it.x, groundY - it.height, it.x + it.width, groundY, paint) }
        paint.alpha = 255
    }

    private fun drawGround(canvas: Canvas) {
        val groundRect = RectF(0f, groundY, screenWidth, screenHeight)

        // Ground fill
        val groundColor = when (environment) {
            NeonPaint.Environment.CITY -> Color.parseColor("#0A0A0A")
            NeonPaint.Environment.JUNGLE -> Color.parseColor("#0D1B0D")
            NeonPaint.Environment.CYBER_NEON -> Color.parseColor("#050010")
        }
        paint.color = groundColor
        paint.alpha = 255
        paint.style = Paint.Style.FILL
        canvas.drawRect(groundRect, paint)

        // Ground neon line
        val lineColor = when (environment) {
            NeonPaint.Environment.CITY -> Color.parseColor("#00BFFF")
            NeonPaint.Environment.JUNGLE -> Color.parseColor("#00E676")
            NeonPaint.Environment.CYBER_NEON -> Color.parseColor("#EA80FC")
        }
        paint.color = lineColor
        paint.strokeWidth = 3f
        paint.style = Paint.Style.STROKE
        paint.maskFilter = android.graphics.BlurMaskFilter(6f, android.graphics.BlurMaskFilter.Blur.NORMAL)
        canvas.drawLine(0f, groundY, screenWidth, groundY, paint)
        paint.maskFilter = null

        // Moving ground grid
        val gridSpacing = 60f
        val gridOffset = (tickCount * currentSpeed * 0.5f) % gridSpacing
        paint.color = lineColor
        paint.alpha = 30
        paint.strokeWidth = 1f
        var gx = -gridOffset
        while (gx < screenWidth) {
            canvas.drawLine(gx, groundY, gx + 20f, screenHeight, paint)
            gx += gridSpacing
        }
        paint.alpha = 255
        paint.maskFilter = null
    }

    data class BgElement(var x: Float, var y: Float, val width: Float, var height: Float)
}
