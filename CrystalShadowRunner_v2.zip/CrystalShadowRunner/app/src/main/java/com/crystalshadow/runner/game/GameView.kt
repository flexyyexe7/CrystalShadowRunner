package com.crystalshadow.runner.game

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.view.MotionEvent
import android.view.SurfaceHolder
import android.view.SurfaceView
import com.crystalshadow.runner.AppConfig

/**
 * SurfaceView-based game view with a dedicated render thread.
 * Targets 60 FPS. Handles all input gestures.
 */
@SuppressLint("ClickableViewAccessibility")
class GameView(context: Context) : SurfaceView(context), SurfaceHolder.Callback {

    private lateinit var gameEngine: GameEngine
    private var gameThread: GameThread? = null

    private var initialized = false
    private var touchStartX = 0f
    private var touchStartY = 0f
    private var touchStartTime = 0L

    // HUD paint
    private val hudPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fpsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 24f
        alpha = 150
    }

    // FPS counter
    private var frameCount = 0
    private var fpsTimer = System.currentTimeMillis()
    private var currentFps = 0

    // Callbacks to Activity
    var onGameOver: ((score: Int, crystals: Int) -> Unit)? = null
    var onScoreUpdated: ((score: Int) -> Unit)? = null
    var onCrystalUpdated: ((crystals: Int) -> Unit)? = null
    var onPowerUpActivated: ((type: Player.PowerUpType) -> Unit)? = null

    init {
        holder.addCallback(this)
        holder.setFormat(PixelFormat.TRANSLUCENT)
        isFocusable = true
        isFocusableInTouchMode = true
        setBackgroundColor(Color.BLACK)
        setupTouchInput()
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupTouchInput() {
        setOnTouchListener { _, event ->
            handleTouch(event)
            true
        }
    }

    private fun handleTouch(event: MotionEvent) {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                touchStartX = event.x
                touchStartY = event.y
                touchStartTime = System.currentTimeMillis()
            }
            MotionEvent.ACTION_UP -> {
                val dx = event.x - touchStartX
                val dy = event.y - touchStartY
                val dt = System.currentTimeMillis() - touchStartTime

                when {
                    // Swipe down → slide
                    dy > 80f && Math.abs(dx) < Math.abs(dy) -> gameEngine.slide()

                    // Swipe right → dash
                    dx > 100f && Math.abs(dy) < 60f && dt < 300 -> gameEngine.dash()

                    // Tap → jump
                    Math.abs(dx) < 30f && Math.abs(dy) < 30f -> gameEngine.jump()
                }
            }
        }
    }

    override fun surfaceCreated(holder: SurfaceHolder) {
        if (!initialized) {
            gameEngine = GameEngine(context, width.toFloat(), height.toFloat())
            gameEngine.onGameOver = { score, crystals ->
                onGameOver?.invoke(score, crystals)
            }
            gameEngine.onScoreUpdated = { score -> onScoreUpdated?.invoke(score) }
            gameEngine.onCrystalCollected = { crystals -> onCrystalUpdated?.invoke(crystals) }
            gameEngine.onPowerUpActivated = { type -> onPowerUpActivated?.invoke(type) }
            initialized = true
        }

        gameThread = GameThread(holder, this).also { it.start() }
    }

    override fun surfaceDestroyed(holder: SurfaceHolder) {
        gameThread?.running = false
        gameThread?.join()
        gameThread = null
    }

    override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {}

    fun updateGame() {
        if (::gameEngine.isInitialized) gameEngine.update()
    }

    override fun draw(canvas: Canvas) {
        super.draw(canvas)
        if (!::gameEngine.isInitialized) return

        gameEngine.draw(canvas)
        drawHUD(canvas)

        if (AppConfig.DEBUG_SHOW_FPS) {
            canvas.drawText("FPS: $currentFps", 20f, 50f, fpsPaint)
        }

        // FPS counter
        frameCount++
        val now = System.currentTimeMillis()
        if (now - fpsTimer >= 1000) {
            currentFps = frameCount
            frameCount = 0
            fpsTimer = now
        }
    }

    private fun drawHUD(canvas: Canvas) {
        if (!::gameEngine.isInitialized) return
        // HUD is rendered in the GameActivity overlay for better UI flexibility
    }

    fun pauseGame() = gameEngine.pause()
    fun resumeGame() = gameEngine.resume()

    fun isGameOver() = ::gameEngine.isInitialized &&
            gameEngine.state == GameEngine.State.GAME_OVER

    fun getScore() = if (::gameEngine.isInitialized) gameEngine.score else 0
    fun getCrystals() = if (::gameEngine.isInitialized) gameEngine.crystalCount else 0
}

/**
 * Dedicated game thread targeting 60 FPS.
 */
class GameThread(
    private val surfaceHolder: SurfaceHolder,
    private val gameView: GameView
) : Thread("GameThread") {

    var running = true
    private val targetFps = 60
    private val frameTime = 1000L / targetFps

    override fun run() {
        var lastTime = System.currentTimeMillis()

        while (running) {
            val now = System.currentTimeMillis()
            val elapsed = now - lastTime
            lastTime = now

            if (gameView.isGameOver()) {
                running = false
                break
            }

            gameView.updateGame()

            val canvas: Canvas? = try {
                surfaceHolder.lockCanvas()
            } catch (e: Exception) { null }

            if (canvas != null) {
                try {
                    gameView.draw(canvas)
                } finally {
                    surfaceHolder.unlockCanvasAndPost(canvas)
                }
            }

            // Cap to target FPS
            val sleepTime = frameTime - (System.currentTimeMillis() - now)
            if (sleepTime > 0) sleep(sleepTime)
        }
    }
}
