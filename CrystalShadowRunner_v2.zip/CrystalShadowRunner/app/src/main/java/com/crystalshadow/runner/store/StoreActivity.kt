package com.crystalshadow.runner.store

import android.graphics.Color
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.crystalshadow.runner.R
import com.crystalshadow.runner.data.PlayerDataManager
import com.crystalshadow.runner.payment.RazorpayManager
import com.crystalshadow.runner.payment.StoreItem
import com.crystalshadow.runner.payment.StoreItemCatalog
import com.crystalshadow.runner.payment.StoreItemType
import com.crystalshadow.runner.utils.SoundManager
import com.razorpay.PaymentResultListener

/**
 * In-game Store Screen.
 * Implements PaymentResultListener to handle Razorpay callbacks.
 */
class StoreActivity : AppCompatActivity(), PaymentResultListener {

    private lateinit var tvCrystals: TextView
    private lateinit var rvStoreItems: RecyclerView
    private var currentPurchaseItem: StoreItem? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        setContentView(R.layout.activity_store)

        tvCrystals = findViewById(R.id.tvCrystals)
        rvStoreItems = findViewById(R.id.rvStoreItems)

        updateCrystalDisplay()
        setupStoreList()
        setupLuckyChest()

        findViewById<View>(R.id.btnBack).setOnClickListener {
            SoundManager.playClick()
            finish()
        }
    }

    private fun updateCrystalDisplay() {
        tvCrystals.text = "💎 ${PlayerDataManager.getCrystals()}"
    }

    private fun setupStoreList() {
        val adapter = StoreAdapter(StoreItemCatalog.allItems) { item ->
            initiatePayment(item)
        }
        rvStoreItems.layoutManager = LinearLayoutManager(this)
        rvStoreItems.adapter = adapter
    }

    private fun setupLuckyChest() {
        val chestCost = com.crystalshadow.runner.AppConfig.LUCKY_CHEST_COST_CRYSTALS
        findViewById<TextView>(R.id.tvChestCost).text = "$chestCost 💎"

        findViewById<View>(R.id.btnLuckyChest).setOnClickListener {
            SoundManager.playChest()
            val reward = PlayerDataManager.openLuckyChest()
            if (reward != null) {
                updateCrystalDisplay()
                showRewardDialog("🎁 Lucky Chest!", "You won $reward 💎 Crystals!", reward)
            } else {
                showToast("Not enough crystals! Need $chestCost 💎")
            }
        }
    }

    /**
     * Starts the Razorpay payment flow for a store item.
     */
    private fun initiatePayment(item: StoreItem) {
        SoundManager.playClick()
        currentPurchaseItem = item

        // Show confirmation dialog before opening payment
        AlertDialog.Builder(this)
            .setTitle("${item.iconEmoji} ${item.title}")
            .setMessage("Purchase ${item.title} for ${item.priceDisplay}?")
            .setPositiveButton("Buy Now") { _, _ ->
                RazorpayManager.startPayment(
                    activity = this,
                    item = item,
                    onSuccess = { /* handled via PaymentResultListener */ },
                    onFailure = { reason -> showToast(reason) }
                )
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ─── Razorpay Payment Callbacks ───────────────────────────────

    /**
     * Called by Razorpay SDK on successful payment.
     * Delivers the purchased reward instantly.
     */
    override fun onPaymentSuccess(razorpayPaymentId: String?) {
        val deliveredItem = RazorpayManager.handlePaymentSuccess(razorpayPaymentId ?: "")
        updateCrystalDisplay()

        deliveredItem?.let { item ->
            val msg = when (item.type) {
                StoreItemType.CRYSTALS_100  -> "✅ 100 Crystals added to your wallet!"
                StoreItemType.CRYSTALS_500  -> "✅ 500 Crystals added to your wallet!"
                StoreItemType.CRYSTALS_1000 -> "✅ 1000 Crystals added to your wallet!"
                StoreItemType.LEGENDARY_SKIN -> "✅ Legendary Skin Unlocked!"
                StoreItemType.REMOVE_ADS    -> "✅ Ads Removed! Enjoy ad-free gaming!"
            }
            showRewardDialog("Payment Successful! 🎉", msg, item.crystalReward)
        }
    }

    /**
     * Called by Razorpay SDK on payment failure or cancellation.
     */
    override fun onPaymentError(errorCode: Int, errorDescription: String?) {
        val userMessage = RazorpayManager.handlePaymentError(
            errorCode,
            errorDescription ?: "Unknown error"
        )
        showPaymentFailureDialog(userMessage)
    }

    private fun showRewardDialog(title: String, message: String, crystals: Int) {
        AlertDialog.Builder(this)
            .setTitle(title)
            .setMessage(message)
            .setPositiveButton("Awesome! 🎉", null)
            .show()
    }

    private fun showPaymentFailureDialog(reason: String) {
        AlertDialog.Builder(this)
            .setTitle("❌ Payment Failed")
            .setMessage("$reason\n\nPlease try again.")
            .setPositiveButton("Try Again") { _, _ ->
                currentPurchaseItem?.let { initiatePayment(it) }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showToast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()
    }
}

// ─────────────────────────────────────────────────────────────────
//  STORE ITEM ADAPTER
// ─────────────────────────────────────────────────────────────────

class StoreAdapter(
    private val items: List<StoreItem>,
    private val onBuy: (StoreItem) -> Unit
) : RecyclerView.Adapter<StoreAdapter.VH>() {

    inner class VH(view: View) : RecyclerView.ViewHolder(view) {
        val tvIcon    : TextView = view.findViewById(R.id.tvItemIcon)
        val tvTitle   : TextView = view.findViewById(R.id.tvItemTitle)
        val tvDesc    : TextView = view.findViewById(R.id.tvItemDesc)
        val tvPrice   : TextView = view.findViewById(R.id.tvItemPrice)
        val btnBuy    : Button   = view.findViewById(R.id.btnBuyItem)
        val badgePopular: TextView = view.findViewById(R.id.tvPopularBadge)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val v = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_store, parent, false)
        return VH(v)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val item = items[position]
        holder.tvIcon.text  = item.iconEmoji
        holder.tvTitle.text = item.title
        holder.tvDesc.text  = item.description
        holder.tvPrice.text = item.priceDisplay
        holder.badgePopular.visibility = if (item.isPopular) View.VISIBLE else View.GONE

        // Check already owned
        val alreadyOwned = when (item.type) {
            StoreItemType.LEGENDARY_SKIN ->
                com.crystalshadow.runner.data.PlayerDataManager.hasSkin("skin_legendary")
            StoreItemType.REMOVE_ADS ->
                com.crystalshadow.runner.data.PlayerDataManager.hasRemovedAds()
            else -> false
        }

        if (alreadyOwned) {
            holder.btnBuy.text = "✓ Owned"
            holder.btnBuy.isEnabled = false
            holder.btnBuy.setBackgroundColor(Color.parseColor("#37474F"))
        } else {
            holder.btnBuy.text = "Buy ${item.priceDisplay}"
            holder.btnBuy.isEnabled = true
            holder.btnBuy.setOnClickListener { onBuy(item) }
        }
    }

    override fun getItemCount() = items.size
}
