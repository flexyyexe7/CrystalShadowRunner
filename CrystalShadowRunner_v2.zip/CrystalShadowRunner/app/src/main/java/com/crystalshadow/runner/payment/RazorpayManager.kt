package com.crystalshadow.runner.payment

import android.app.Activity
import android.util.Log
import com.crystalshadow.runner.AppConfig
import com.crystalshadow.runner.data.PlayerDataManager
import com.razorpay.Checkout
import com.razorpay.PaymentResultListener
import org.json.JSONObject

/**
 * ══════════════════════════════════════════════════════
 *  RAZORPAY PAYMENT MANAGER
 *  Handles all in-app purchases via Razorpay Checkout.
 *
 *  HOW TO USE:
 *  1. Add your RAZORPAY_KEY_ID in AppConfig.kt
 *  2. Call RazorpayManager.startPayment(...) from any Activity
 *  3. Implement PaymentResultListener in your Activity
 * ══════════════════════════════════════════════════════
 */
object RazorpayManager {

    private const val TAG = "RazorpayManager"

    // Currently pending purchase — used to fulfill after payment success
    private var pendingPurchase: StoreItem? = null

    /**
     * Pre-loads Razorpay SDK for faster checkout popup.
     * Call this in MainActivity.onCreate()
     */
    fun preload(activity: Activity) {
        Checkout.preload(activity.applicationContext)
    }

    /**
     * Starts the Razorpay payment flow for a store item.
     *
     * @param activity  The calling Activity (must implement PaymentResultListener)
     * @param item      The StoreItem being purchased
     * @param onSuccess Called when payment succeeds and reward is delivered
     * @param onFailure Called when payment fails or is cancelled
     */
    fun startPayment(
        activity: Activity,
        item: StoreItem,
        onSuccess: (item: StoreItem) -> Unit,
        onFailure: (reason: String) -> Unit
    ) {
        pendingPurchase = item

        val checkout = Checkout()
        checkout.setKeyID(AppConfig.RAZORPAY_KEY_ID)

        try {
            val options = JSONObject().apply {
                put("name", AppConfig.BUSINESS_NAME)
                put("description", item.description)
                put("image", "https://i.imgur.com/placeholder.png") // Replace with your logo URL
                put("theme.color", "#00FFFF")
                put("currency", AppConfig.CURRENCY)
                put("amount", item.priceInPaise)  // Amount in paise

                // Prefill — optional, for faster checkout
                put("prefill", JSONObject().apply {
                    put("name", PlayerDataManager.getPlayerName())
                    put("email", "player@crystalshadow.com")
                })

                // UPI as preferred method
                put("config", JSONObject().apply {
                    put("display", JSONObject().apply {
                        put("blocks", JSONObject().apply {
                            put("utib", JSONObject().apply {
                                put("name", "Pay via UPI")
                                put("instruments", org.json.JSONArray().apply {
                                    put(JSONObject().apply {
                                        put("method", "upi")
                                    })
                                })
                            })
                        })
                        put("sequence", org.json.JSONArray().apply { put("block.utib") })
                        put("preferences", JSONObject().apply { put("show_default_blocks", true) })
                    })
                })
            }

            checkout.open(activity, options)

        } catch (e: Exception) {
            Log.e(TAG, "Error starting Razorpay payment", e)
            onFailure("Unable to open payment. Please try again.")
            pendingPurchase = null
        }
    }

    /**
     * Call this from onPaymentSuccess() in your Activity.
     * Delivers the purchased reward to the player.
     */
    fun handlePaymentSuccess(razorpayPaymentId: String): StoreItem? {
        val item = pendingPurchase ?: return null

        Log.d(TAG, "Payment SUCCESS | ID: $razorpayPaymentId | Item: ${item.title}")

        // Deliver reward instantly
        when (item.type) {
            StoreItemType.CRYSTALS_100 -> PlayerDataManager.addCrystals(AppConfig.CRYSTALS_PACK_SMALL)
            StoreItemType.CRYSTALS_500 -> PlayerDataManager.addCrystals(AppConfig.CRYSTALS_PACK_MEDIUM)
            StoreItemType.CRYSTALS_1000 -> PlayerDataManager.addCrystals(AppConfig.CRYSTALS_PACK_LARGE)
            StoreItemType.LEGENDARY_SKIN -> {
                PlayerDataManager.unlockSkin("skin_legendary")
                PlayerDataManager.setActiveSkin("skin_legendary")
            }
            StoreItemType.REMOVE_ADS -> PlayerDataManager.setRemoveAds(true)
        }

        // TODO: Optionally verify payment on your backend:
        // POST to AppConfig.PAYMENT_WEBHOOK_URL with razorpayPaymentId
        // verifyPaymentOnServer(razorpayPaymentId, item)

        pendingPurchase = null
        return item
    }

    /**
     * Call this from onPaymentError() in your Activity.
     */
    fun handlePaymentError(code: Int, description: String): String {
        Log.e(TAG, "Payment FAILED | Code: $code | Reason: $description")
        pendingPurchase = null

        return when (code) {
            Checkout.NETWORK_ERROR -> "Network error. Please check your connection."
            Checkout.INVALID_OPTIONS -> "Payment configuration error."
            else -> "Payment Failed. Please try again."
        }
    }

    /**
     * Optional: Verify payment on your backend server.
     * This provides extra security against tampered payments.
     */
    private fun verifyPaymentOnServer(paymentId: String, item: StoreItem) {
        // Use Retrofit or OkHttp to POST:
        // {
        //   "razorpay_payment_id": paymentId,
        //   "item_id": item.type.name,
        //   "player_id": PlayerDataManager.getPlayerName()
        // }
        // to AppConfig.PAYMENT_WEBHOOK_URL
        //
        // Your server should verify the signature using RAZORPAY_SECRET
        // and then confirm the purchase.
    }
}
