package com.crystalshadow.runner

/**
 * ╔══════════════════════════════════════════════════════════════╗
 * ║          CRYSTAL SHADOW RUNNER - DEVELOPER CONFIG            ║
 * ║                                                              ║
 * ║  Edit this file to configure payment, pricing & gameplay.    ║
 * ╚══════════════════════════════════════════════════════════════╝
 *
 * HOW TO ENABLE PAYMENTS:
 * 1. Go to https://dashboard.razorpay.com → Settings → API Keys
 * 2. Copy your Key ID and paste it in RAZORPAY_KEY_ID below
 * 3. Set your UPI_ID for direct UPI payments
 * 4. Optionally set PAYMENT_WEBHOOK_URL for server-side verification
 *
 * NOTE: Never commit your RAZORPAY_SECRET to version control!
 * Store it on your backend server only.
 */
object AppConfig {

    // ─────────────────────────────────────────────────────────────
    //  RAZORPAY PAYMENT CONFIGURATION
    // ─────────────────────────────────────────────────────────────

    /** Your Razorpay Key ID from the dashboard */
    const val RAZORPAY_KEY_ID = "rzp_test_REPLACE_WITH_YOUR_KEY"  // ← REPLACE THIS

    /**
     * Razorpay Secret — DO NOT put this in the app!
     * Use it ONLY on your backend server for order creation & verification.
     */
    const val RAZORPAY_SECRET = "KEEP_ON_SERVER_ONLY"  // ← BACKEND ONLY

    /** Your UPI ID for direct UPI payments */
    const val UPI_ID = "your-upi@paytm"  // ← REPLACE THIS

    /** Backend webhook URL for payment verification (optional but recommended) */
    const val PAYMENT_WEBHOOK_URL = "https://your-server.com/api/payment/verify"  // ← REPLACE

    /** Your business/app name shown on the Razorpay checkout screen */
    const val BUSINESS_NAME = "Crystal Shadow Runner"

    /** Currency code */
    const val CURRENCY = "INR"

    // ─────────────────────────────────────────────────────────────
    //  CRYSTAL STORE PRICING (in Paise — 1 INR = 100 Paise)
    // ─────────────────────────────────────────────────────────────

    const val PRICE_100_CRYSTALS_PAISE = 2000    // ₹20
    const val PRICE_500_CRYSTALS_PAISE = 7900    // ₹79
    const val PRICE_1000_CRYSTALS_PAISE = 14900  // ₹149
    const val PRICE_LEGENDARY_SKIN_PAISE = 19900 // ₹199
    const val PRICE_REMOVE_ADS_PAISE = 9900      // ₹99

    // ─────────────────────────────────────────────────────────────
    //  CRYSTAL AMOUNTS PER PURCHASE
    // ─────────────────────────────────────────────────────────────

    const val CRYSTALS_PACK_SMALL = 100
    const val CRYSTALS_PACK_MEDIUM = 500
    const val CRYSTALS_PACK_LARGE = 1000

    // ─────────────────────────────────────────────────────────────
    //  GAMEPLAY CONFIGURATION
    // ─────────────────────────────────────────────────────────────

    /** Starting game speed (pixels per second) */
    const val GAME_SPEED_INITIAL = 8f

    /** Maximum game speed */
    const val GAME_SPEED_MAX = 20f

    /** Speed increase per second of survival */
    const val GAME_SPEED_INCREMENT = 0.002f

    /** How many crystals the player starts with */
    const val STARTING_CRYSTALS = 50

    /** Crystals earned per 100 score points */
    const val CRYSTAL_REWARD_RATE = 1

    /** Gravity strength */
    const val GRAVITY = 0.8f

    /** Jump force */
    const val JUMP_FORCE = -18f

    // ─────────────────────────────────────────────────────────────
    //  POWER-UP DURATIONS (in milliseconds)
    // ─────────────────────────────────────────────────────────────

    const val POWERUP_LIGHTNING_DASH_DURATION = 3000L   // 3 seconds
    const val POWERUP_SHIELD_DURATION = 5000L            // 5 seconds
    const val POWERUP_FIRE_TRAIL_DURATION = 4000L        // 4 seconds
    const val POWERUP_SHADOW_TELEPORT_DURATION = 2000L   // 2 seconds

    // ─────────────────────────────────────────────────────────────
    //  DAILY REWARD CONFIGURATION
    // ─────────────────────────────────────────────────────────────

    val DAILY_REWARD_CRYSTALS = intArrayOf(10, 20, 30, 50, 75, 100, 200)

    // ─────────────────────────────────────────────────────────────
    //  LUCKY CHEST CONFIGURATION
    // ─────────────────────────────────────────────────────────────

    const val LUCKY_CHEST_COST_CRYSTALS = 50
    val LUCKY_CHEST_REWARDS = intArrayOf(25, 50, 75, 100, 200, 500)

    // ─────────────────────────────────────────────────────────────
    //  ADS CONFIGURATION
    // ─────────────────────────────────────────────────────────────

    const val REWARDED_AD_CRYSTAL_REWARD = 25
    const val ADMOB_APP_ID = "ca-app-pub-REPLACE_WITH_YOUR_ID"  // ← REPLACE

    // ─────────────────────────────────────────────────────────────
    //  LEADERBOARD
    // ─────────────────────────────────────────────────────────────

    const val MAX_LEADERBOARD_ENTRIES = 100

    // ─────────────────────────────────────────────────────────────
    //  DEBUG FLAGS
    // ─────────────────────────────────────────────────────────────

    const val DEBUG_SHOW_FPS = false
    const val DEBUG_GOD_MODE = false  // Set true to test without dying
    const val DEBUG_INFINITE_CRYSTALS = false
}
