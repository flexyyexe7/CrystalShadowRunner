package com.crystalshadow.runner.utils

import android.graphics.BlurMaskFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader

/**
 * Utility object for drawing neon-style glowing UI elements on Canvas.
 */
object NeonPaint {

    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val strokePaint = Paint(Paint.ANTI_ALIAS_FLAG)

    /**
     * Draw a neon glowing rectangle (used for buttons, panels).
     */
    fun drawNeonRect(
        canvas: Canvas,
        rect: RectF,
        fillColor: Int,
        glowColor: Int,
        cornerRadius: Float = 20f,
        glowRadius: Float = 15f,
        alpha: Int = 255
    ) {
        // Outer glow
        glowPaint.style = Paint.Style.FILL
        glowPaint.color = glowColor
        glowPaint.alpha = (alpha * 0.4f).toInt()
        glowPaint.maskFilter = BlurMaskFilter(glowRadius, BlurMaskFilter.Blur.OUTER)
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, glowPaint)

        // Fill
        fillPaint.style = Paint.Style.FILL
        fillPaint.color = fillColor
        fillPaint.alpha = alpha
        fillPaint.maskFilter = null
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, fillPaint)

        // Border
        strokePaint.style = Paint.Style.STROKE
        strokePaint.color = glowColor
        strokePaint.strokeWidth = 2f
        strokePaint.alpha = alpha
        strokePaint.maskFilter = BlurMaskFilter(4f, BlurMaskFilter.Blur.NORMAL)
        canvas.drawRoundRect(rect, cornerRadius, cornerRadius, strokePaint)

        glowPaint.maskFilter = null
        strokePaint.maskFilter = null
    }

    /**
     * Draw neon glowing text.
     */
    fun drawNeonText(
        canvas: Canvas,
        text: String,
        x: Float,
        y: Float,
        textColor: Int,
        glowColor: Int,
        textSize: Float,
        glowRadius: Float = 12f,
        alpha: Int = 255
    ) {
        textPaint.textSize = textSize
        textPaint.textAlign = Paint.Align.CENTER
        textPaint.isFakeBoldText = true

        // Glow layer
        textPaint.color = glowColor
        textPaint.alpha = (alpha * 0.6f).toInt()
        textPaint.maskFilter = BlurMaskFilter(glowRadius, BlurMaskFilter.Blur.NORMAL)
        canvas.drawText(text, x, y, textPaint)

        // Main text
        textPaint.color = textColor
        textPaint.alpha = alpha
        textPaint.maskFilter = null
        canvas.drawText(text, x, y, textPaint)

        textPaint.maskFilter = null
    }

    /**
     * Draw a crystal icon (hexagonal shape with glow).
     */
    fun drawCrystal(canvas: Canvas, cx: Float, cy: Float, size: Float, alpha: Int = 255) {
        fillPaint.style = Paint.Style.FILL
        fillPaint.alpha = alpha

        // Gradient fill for crystal
        fillPaint.shader = LinearGradient(
            cx - size, cy - size, cx + size, cy + size,
            Color.parseColor("#00FFFF"),
            Color.parseColor("#7B2FBE"),
            Shader.TileMode.CLAMP
        )

        // Draw diamond shape
        val path = android.graphics.Path().apply {
            moveTo(cx, cy - size)
            lineTo(cx + size * 0.6f, cy - size * 0.3f)
            lineTo(cx + size * 0.6f, cy + size * 0.3f)
            lineTo(cx, cy + size)
            lineTo(cx - size * 0.6f, cy + size * 0.3f)
            lineTo(cx - size * 0.6f, cy - size * 0.3f)
            close()
        }

        // Glow
        glowPaint.style = Paint.Style.FILL
        glowPaint.color = Color.CYAN
        glowPaint.alpha = (alpha * 0.5f).toInt()
        glowPaint.maskFilter = BlurMaskFilter(size * 0.8f, BlurMaskFilter.Blur.NORMAL)
        canvas.drawPath(path, glowPaint)
        glowPaint.maskFilter = null

        canvas.drawPath(path, fillPaint)
        fillPaint.shader = null
    }

    /**
     * Draw a star burst effect (used for power-up indicators).
     */
    fun drawStarBurst(
        canvas: Canvas,
        cx: Float,
        cy: Float,
        innerRadius: Float,
        outerRadius: Float,
        color: Int,
        points: Int = 8,
        rotation: Float = 0f
    ) {
        val path = android.graphics.Path()
        val angleStep = 360f / (points * 2)
        var currentAngle = rotation

        for (i in 0 until points * 2) {
            val r = if (i % 2 == 0) outerRadius else innerRadius
            val rad = currentAngle * Math.PI.toFloat() / 180f
            val x = cx + r * kotlin.math.cos(rad)
            val y = cy + r * kotlin.math.sin(rad)

            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            currentAngle += angleStep
        }
        path.close()

        fillPaint.shader = null
        fillPaint.color = color
        fillPaint.alpha = 200
        fillPaint.maskFilter = BlurMaskFilter(8f, BlurMaskFilter.Blur.NORMAL)
        canvas.drawPath(path, fillPaint)
        fillPaint.maskFilter = null
    }

    /**
     * Draw a background gradient for a game environment.
     */
    fun drawBackground(canvas: Canvas, width: Float, height: Float, environment: Environment) {
        val shader = when (environment) {
            Environment.CITY -> LinearGradient(
                0f, 0f, 0f, height,
                intArrayOf(
                    Color.parseColor("#0A0A1A"),
                    Color.parseColor("#1A0A2E"),
                    Color.parseColor("#16213E")
                ),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
            Environment.JUNGLE -> LinearGradient(
                0f, 0f, 0f, height,
                intArrayOf(
                    Color.parseColor("#0D1B2A"),
                    Color.parseColor("#1B4332"),
                    Color.parseColor("#081C15")
                ),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
            Environment.CYBER_NEON -> LinearGradient(
                0f, 0f, 0f, height,
                intArrayOf(
                    Color.parseColor("#0D0221"),
                    Color.parseColor("#241734"),
                    Color.parseColor("#0A0015")
                ),
                floatArrayOf(0f, 0.5f, 1f),
                Shader.TileMode.CLAMP
            )
        }

        fillPaint.shader = shader
        fillPaint.alpha = 255
        canvas.drawRect(0f, 0f, width, height, fillPaint)
        fillPaint.shader = null
    }

    enum class Environment { CITY, JUNGLE, CYBER_NEON }
}
