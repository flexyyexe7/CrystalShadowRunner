package com.crystalshadow.runner.utils

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.SoundPool
import com.crystalshadow.runner.data.PlayerDataManager

/**
 * Manages all game audio: background music and sound effects.
 * Sound effects use SoundPool for low-latency playback.
 * Background music uses MediaPlayer.
 */
object SoundManager {

    private lateinit var soundPool: SoundPool
    private var mediaPlayer: MediaPlayer? = null

    // Sound effect IDs
    private var soundJump = 0
    private var soundCrystalCollect = 0
    private var soundPowerUp = 0
    private var soundGameOver = 0
    private var soundClick = 0
    private var soundDash = 0
    private var soundShield = 0
    private var soundChest = 0

    private var initialized = false

    fun init(context: Context) {
        if (initialized) return

        val attributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        soundPool = SoundPool.Builder()
            .setMaxStreams(8)
            .setAudioAttributes(attributes)
            .build()

        // Load sound effects from assets
        // In a real project, put sound files in res/raw/
        // Here we gracefully handle missing files
        try {
            val am = context.assets
            // These would be: R.raw.jump, R.raw.crystal_collect, etc.
            // soundJump = soundPool.load(context, R.raw.jump, 1)
            // soundCrystalCollect = soundPool.load(context, R.raw.crystal_collect, 1)
            // soundPowerUp = soundPool.load(context, R.raw.power_up, 1)
            // soundGameOver = soundPool.load(context, R.raw.game_over, 1)
            // soundClick = soundPool.load(context, R.raw.click, 1)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        initialized = true
    }

    fun playJump() = playSound(soundJump)
    fun playCrystalCollect() = playSound(soundCrystalCollect)
    fun playPowerUp() = playSound(soundPowerUp)
    fun playGameOver() = playSound(soundGameOver)
    fun playClick() = playSound(soundClick)
    fun playDash() = playSound(soundDash)
    fun playShield() = playSound(soundShield)
    fun playChest() = playSound(soundChest)

    private fun playSound(soundId: Int) {
        if (!PlayerDataManager.isSoundEnabled()) return
        if (!initialized || soundId == 0) return
        soundPool.play(soundId, 1f, 1f, 1, 0, 1f)
    }

    fun startBackgroundMusic(context: Context) {
        if (!PlayerDataManager.isMusicEnabled()) return
        try {
            // mediaPlayer = MediaPlayer.create(context, R.raw.bg_cyber_music)
            mediaPlayer?.apply {
                isLooping = true
                setVolume(0.5f, 0.5f)
                start()
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun pauseMusic() {
        mediaPlayer?.pause()
    }

    fun resumeMusic() {
        if (!PlayerDataManager.isMusicEnabled()) return
        mediaPlayer?.start()
    }

    fun stopMusic() {
        mediaPlayer?.stop()
        mediaPlayer?.reset()
    }

    fun setMusicVolume(volume: Float) {
        mediaPlayer?.setVolume(volume, volume)
    }

    fun release() {
        soundPool.release()
        mediaPlayer?.release()
        mediaPlayer = null
        initialized = false
    }
}
