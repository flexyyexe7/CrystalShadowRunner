package com.crystalshadow.runner.data

import android.content.Context
import android.content.SharedPreferences
import com.crystalshadow.runner.AppConfig
import java.util.Date

/**
 * Manages all persistent player data using SharedPreferences.
 * Handles crystals, high scores, skins, daily rewards, and settings.
 */
object PlayerDataManager {

    private const val PREFS_NAME = "crystal_shadow_prefs"
    private const val KEY_CRYSTALS = "crystals"
    private const val KEY_HIGH_SCORE = "high_score"
    private const val KEY_TOTAL_SCORE = "total_score"
    private const val KEY_GAMES_PLAYED = "games_played"
    private const val KEY_ACTIVE_SKIN = "active_skin"
    private const val KEY_OWNED_SKINS = "owned_skins"
    private const val KEY_REMOVE_ADS = "remove_ads"
    private const val KEY_LAST_DAILY_REWARD = "last_daily_reward"
    private const val KEY_DAILY_REWARD_DAY = "daily_reward_day"
    private const val KEY_DAILY_REWARD_STREAK = "daily_reward_streak"
    private const val KEY_SOUND_ENABLED = "sound_enabled"
    private const val KEY_MUSIC_ENABLED = "music_enabled"
    private const val KEY_VIBRATION_ENABLED = "vibration_enabled"
    private const val KEY_PLAYER_NAME = "player_name"
    private const val KEY_LAST_CHEST_OPEN = "last_chest_open"
    private const val KEY_FIRST_LAUNCH = "first_launch"

    private lateinit var prefs: SharedPreferences

    fun init(context: Context) {
        prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

        // Give starting crystals on first launch
        if (isFirstLaunch()) {
            setCrystals(AppConfig.STARTING_CRYSTALS)
            markFirstLaunchDone()
        }
    }

    // ─── Crystal Operations ───────────────────────────────────────

    fun getCrystals(): Int = prefs.getInt(KEY_CRYSTALS, AppConfig.STARTING_CRYSTALS)

    fun setCrystals(amount: Int) = prefs.edit().putInt(KEY_CRYSTALS, amount).apply()

    fun addCrystals(amount: Int) {
        val current = getCrystals()
        setCrystals(current + amount)
    }

    fun spendCrystals(amount: Int): Boolean {
        val current = getCrystals()
        return if (current >= amount) {
            setCrystals(current - amount)
            true
        } else false
    }

    // ─── Score Operations ─────────────────────────────────────────

    fun getHighScore(): Int = prefs.getInt(KEY_HIGH_SCORE, 0)

    fun submitScore(score: Int) {
        val current = getHighScore()
        if (score > current) {
            prefs.edit().putInt(KEY_HIGH_SCORE, score).apply()
        }
        prefs.edit()
            .putInt(KEY_TOTAL_SCORE, getTotalScore() + score)
            .putInt(KEY_GAMES_PLAYED, getGamesPlayed() + 1)
            .apply()

        // Award crystals for score
        val earned = score / 100 * AppConfig.CRYSTAL_REWARD_RATE
        if (earned > 0) addCrystals(earned)
    }

    fun getTotalScore(): Int = prefs.getInt(KEY_TOTAL_SCORE, 0)
    fun getGamesPlayed(): Int = prefs.getInt(KEY_GAMES_PLAYED, 0)

    // ─── Skin System ──────────────────────────────────────────────

    fun getActiveSkin(): String = prefs.getString(KEY_ACTIVE_SKIN, SkinId.DEFAULT) ?: SkinId.DEFAULT

    fun setActiveSkin(skinId: String) = prefs.edit().putString(KEY_ACTIVE_SKIN, skinId).apply()

    fun getOwnedSkins(): MutableSet<String> {
        val owned = prefs.getStringSet(KEY_OWNED_SKINS, mutableSetOf(SkinId.DEFAULT))
        return owned?.toMutableSet() ?: mutableSetOf(SkinId.DEFAULT)
    }

    fun unlockSkin(skinId: String) {
        val owned = getOwnedSkins()
        owned.add(skinId)
        prefs.edit().putStringSet(KEY_OWNED_SKINS, owned).apply()
    }

    fun hasSkin(skinId: String): Boolean = getOwnedSkins().contains(skinId)

    // ─── Remove Ads ───────────────────────────────────────────────

    fun hasRemovedAds(): Boolean = prefs.getBoolean(KEY_REMOVE_ADS, false)

    fun setRemoveAds(removed: Boolean) = prefs.edit().putBoolean(KEY_REMOVE_ADS, removed).apply()

    // ─── Daily Reward ─────────────────────────────────────────────

    fun canClaimDailyReward(): Boolean {
        val lastClaim = prefs.getLong(KEY_LAST_DAILY_REWARD, 0L)
        val now = System.currentTimeMillis()
        val diff = now - lastClaim
        return diff >= 24 * 60 * 60 * 1000L // 24 hours
    }

    fun claimDailyReward(): Int {
        val day = getDailyRewardDay()
        val reward = AppConfig.DAILY_REWARD_CRYSTALS[day % AppConfig.DAILY_REWARD_CRYSTALS.size]

        addCrystals(reward)
        prefs.edit()
            .putLong(KEY_LAST_DAILY_REWARD, System.currentTimeMillis())
            .putInt(KEY_DAILY_REWARD_DAY, day + 1)
            .apply()

        return reward
    }

    fun getDailyRewardDay(): Int = prefs.getInt(KEY_DAILY_REWARD_DAY, 0)

    // ─── Lucky Chest ──────────────────────────────────────────────

    fun openLuckyChest(): Int? {
        if (!spendCrystals(AppConfig.LUCKY_CHEST_COST_CRYSTALS)) return null
        val rewards = AppConfig.LUCKY_CHEST_REWARDS
        val reward = rewards[(Math.random() * rewards.size).toInt()]
        addCrystals(reward)
        prefs.edit().putLong(KEY_LAST_CHEST_OPEN, System.currentTimeMillis()).apply()
        return reward
    }

    // ─── Settings ─────────────────────────────────────────────────

    fun isSoundEnabled(): Boolean = prefs.getBoolean(KEY_SOUND_ENABLED, true)
    fun setSoundEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_SOUND_ENABLED, enabled).apply()

    fun isMusicEnabled(): Boolean = prefs.getBoolean(KEY_MUSIC_ENABLED, true)
    fun setMusicEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_MUSIC_ENABLED, enabled).apply()

    fun isVibrationEnabled(): Boolean = prefs.getBoolean(KEY_VIBRATION_ENABLED, true)
    fun setVibrationEnabled(enabled: Boolean) = prefs.edit().putBoolean(KEY_VIBRATION_ENABLED, enabled).apply()

    fun getPlayerName(): String = prefs.getString(KEY_PLAYER_NAME, "Shadow Ninja") ?: "Shadow Ninja"
    fun setPlayerName(name: String) = prefs.edit().putString(KEY_PLAYER_NAME, name).apply()

    // ─── Misc ─────────────────────────────────────────────────────

    private fun isFirstLaunch(): Boolean = prefs.getBoolean(KEY_FIRST_LAUNCH, true)

    private fun markFirstLaunchDone() = prefs.edit().putBoolean(KEY_FIRST_LAUNCH, false).apply()
}

/**
 * Skin identifiers — add new skins here.
 */
object SkinId {
    const val DEFAULT = "skin_default"
    const val NEON = "skin_neon"
    const val FIRE = "skin_fire"
    const val LEGENDARY = "skin_legendary"
    const val CYBER = "skin_cyber"
    const val SHADOW = "skin_shadow"
}
