package com.crystalshadow.runner.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query

@Dao
interface LeaderboardDao {
    @Insert
    suspend fun insert(entry: LeaderboardEntry)

    @Query("SELECT * FROM leaderboard ORDER BY score DESC LIMIT :limit")
    suspend fun getTopScores(limit: Int = 100): List<LeaderboardEntry>

    @Query("DELETE FROM leaderboard WHERE id NOT IN (SELECT id FROM leaderboard ORDER BY score DESC LIMIT 100)")
    suspend fun pruneOldEntries()
}
