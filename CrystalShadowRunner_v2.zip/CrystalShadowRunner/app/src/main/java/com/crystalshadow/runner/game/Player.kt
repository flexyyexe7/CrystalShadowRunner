package com.crystalshadow.runner.game

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.crystalshadow.runner.AppConfig
import com.crystalshadow.runner.data.PlayerDataManager
import com.crystalshadow.runner.data.SkinId
import com.crystalshadow.runner.utils.NeonPaint
import com.crystalshadow.runner.utils.ParticleSystem
import com.crystalshadow.runner.utils.SoundManager
import kotlin.math.abs

/**
 * The Shadow Ninja player character.
 * Handles movement (jump, slide, dash), power-ups, animation, and rendering.
 */
class Player(
    private val screenWidth: Float,
    private val screenHeight: Float
) {
    // ─── Position & Size ──────────────────────────────────────────

    val width = 60f
    val height = 80f
    var x = screenWidth * 0.2f
    var y = groundY - height
    var velocityY = 0f

    val hitbox get() = RectF(x + 8f, y + 4f, x + width - 8f, y + height - 4f)

    // ─── State ────────────────────────────────────────────────────

    var isAlive = true
    var isDashing = false
    var isSliding = false
    var isOnGround = true
    var isInvincible = false
    private var jumpCount = 0
    private val maxJumps = 2  // Double jump

    // ─── Power-up State ───────────────────────────────────────────

    var activePowerUp: PowerUpType? = null
    private var powerUpEndTime = 0L

    enum class PowerUpType {
        LIGHTNING_DASH,
        SHIELD_PROTECTION,
        FIRE_TRAIL,
        SHADOW_TELEPORT
    }

    // ─── Animation ────────────────────────────────────────────────

    private var animFrame = 0
    private var animTick = 0
    private val animSpeed = 6  // Frames per animation step
    private var runCycle = 0f
    private var dashPhase = 0f
    private var glowPulse = 0f

    // ─── Visual Effects ───────────────────────────────────────────

    private val particleSystem = ParticleSystem()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)

    // ─── Physics ──────────────────────────────────────────────────

    private val groundY get() = screenHeight * 0.75f

    // ─── Dash State ───────────────────────────────────────────────

    private var dashVelocity = 0f
    private var dashDuration = 0
    private var slideHeight = height
    private var slideTick = 0

    // ─────────────────────────────────────────────────────────────

    fun jump() {
        if (jumpCount < maxJumps) {
            velocityY = AppConfig.JUMP_FORCE
            isOnGround = false
            jumpCount++
            SoundManager.playJump()

            // Double jump sparkle
            if (jumpCount == 2) {
                particleSystem.emitCrystalSparkle(x + width / 2f, y + height)
            }
        }
    }

    fun startSlide() {
        if (isOnGround && !isSliding) {
            isSliding = true
            slideTick = 30  // frames
        }
    }

    fun startDash() {
        if (!isDashing) {
            isDashing = true
            dashVelocity = 25f
            dashDuration = 15
            SoundManager.playDash()
            particleSystem.emitLightningDash(x, y + height / 2f)
        }
    }

    fun activatePowerUp(type: PowerUpType) {
        activePowerUp = type
        isInvincible = type == PowerUpType.SHIELD_PROTECTION

        powerUpEndTime = System.currentTimeMillis() + when (type) {
            PowerUpType.LIGHTNING_DASH -> AppConfig.POWERUP_LIGHTNING_DASH_DURATION
            PowerUpType.SHIELD_PROTECTION -> AppConfig.POWERUP_SHIELD_DURATION
            PowerUpType.FIRE_TRAIL -> AppConfig.POWERUP_FIRE_TRAIL_DURATION
            PowerUpType.SHADOW_TELEPORT -> AppConfig.POWERUP_SHADOW_TELEPORT_DURATION
        }
        SoundManager.playPowerUp()
    }

    fun update(gameSpeed: Float) {
        if (!isAlive) return

        // ── Physics ───────────────────────────────────────────────
        velocityY += AppConfig.GRAVITY
        y += velocityY

        // Ground collision
        if (y + height >= groundY) {
            y = groundY - height
            velocityY = 0f
            isOnGround = true
            jumpCount = 0
        }

        // ── Dash ──────────────────────────────────────────────────
        if (isDashing && dashDuration > 0) {
            x += dashVelocity * 0.1f
            dashVelocity *= 0.85f
            dashDuration--
            dashPhase += 0.3f
            if (dashDuration <= 0) {
                isDashing = false
                dashVelocity = 0f
            }
        }

        // Keep player in screen bounds
        x = x.coerceIn(screenWidth * 0.05f, screenWidth * 0.45f)

        // ── Slide ─────────────────────────────────────────────────
        if (isSliding) {
            slideHeight = height * 0.5f
            slideTick--
            if (slideTick <= 0) {
                isSliding = false
                slideHeight = height
            }
        } else {
            slideHeight = height
        }

        // ── Power-up expiry ───────────────────────────────────────
        if (activePowerUp != null && System.currentTimeMillis() > powerUpEndTime) {
            activePowerUp = null
            isInvincible = false
        }

        // ── Particle effects ──────────────────────────────────────
        when (activePowerUp) {
            PowerUpType.FIRE_TRAIL ->
                particleSystem.emitFireTrail(x, y + slideHeight / 2f)
            PowerUpType.SHADOW_TELEPORT -> {
                if (animTick % 3 == 0)
                    particleSystem.emitShadowTeleport(x + width / 2f, y + slideHeight / 2f)
            }
            PowerUpType.LIGHTNING_DASH -> {
                if (animTick % 2 == 0)
                    particleSystem.emitLightningDash(x, y + slideHeight / 2f)
            }
            else -> {}
        }

        // ── Animation ─────────────────────────────────────────────
        animTick++
        runCycle += if (isOnGround) 0.2f else 0.05f
        glowPulse = (Math.sin(animTick * 0.1) * 0.5f + 0.5f).toFloat()

        if (animTick % animSpeed == 0) {
            animFrame = (animFrame + 1) % 8
        }

        particleSystem.update()
    }

    fun draw(canvas: Canvas) {
        particleSystem.draw(canvas)

        val drawY = y + (height - slideHeight)  // Adjust Y for slide

        // ── Shield ring ───────────────────────────────────────────
        if (activePowerUp == PowerUpType.SHIELD_PROTECTION) {
            paint.color = Color.parseColor("#29B6F6")
            paint.alpha = (120 + glowPulse * 80f).toInt()
            paint.style = Paint.Style.STROKE
            paint.strokeWidth = 4f
            canvas.drawOval(
                x - 20f, drawY - 20f,
                x + width + 20f, drawY + slideHeight + 20f,
                paint
            )
        }

        // ── Body shadow/silhouette ────────────────────────────────
        val skinColor = getSkinColors()

        // Body glow
        paint.style = Paint.Style.FILL
        paint.color = skinColor.glowColor
        paint.alpha = (80 + glowPulse * 60f).toInt()
        canvas.drawRoundRect(
            RectF(x - 6f, drawY - 6f, x + width + 6f, drawY + slideHeight + 6f),
            12f, 12f, paint
        )

        // Main body — draw ninja silhouette
        drawNinjaSilhouette(canvas, x, drawY, width, slideHeight, skinColor)

        // Dash afterimage
        if (isDashing) {
            for (i in 1..3) {
                paint.color = skinColor.primaryColor
                paint.alpha = 80 - i * 20
                canvas.drawRoundRect(
                    RectF(x - i * 12f, drawY, x - i * 12f + width, drawY + slideHeight),
                    8f, 8f, paint
                )
            }
        }
    }

    private fun drawNinjaSilhouette(
        canvas: Canvas,
        px: Float, py: Float,
        pw: Float, ph: Float,
        skin: SkinColors
    ) {
        // Body
        paint.alpha = 255
        paint.color = skin.primaryColor
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(
            RectF(px + pw * 0.2f, py + ph * 0.35f, px + pw * 0.8f, py + ph),
            8f, 8f, paint
        )

        // Head
        canvas.drawOval(
            px + pw * 0.15f, py,
            px + pw * 0.85f, py + ph * 0.4f,
            paint
        )

        // Scarf/mask detail
        paint.color = skin.accentColor
        canvas.drawRect(
            px + pw * 0.1f, py + ph * 0.2f,
            px + pw * 0.9f, py + ph * 0.35f,
            paint
        )

        // Eyes — glowing dots
        paint.color = skin.eyeColor
        paint.alpha = (200 + glowPulse * 55f).toInt().coerceIn(0, 255)
        val eyeY = py + ph * 0.15f
        canvas.drawCircle(px + pw * 0.35f, eyeY, 4f, paint)
        canvas.drawCircle(px + pw * 0.65f, eyeY, 4f, paint)

        // Running legs animation (when on ground and not sliding)
        if (isOnGround && !isSliding) {
            val legOffset1 = (Math.sin(runCycle.toDouble()) * 10f).toFloat()
            val legOffset2 = (Math.sin(runCycle.toDouble() + Math.PI) * 10f).toFloat()

            paint.color = skin.primaryColor
            paint.alpha = 255
            // Left leg
            canvas.drawRoundRect(
                RectF(px + pw * 0.25f, py + ph * 0.75f,
                    px + pw * 0.45f, py + ph + legOffset1),
                6f, 6f, paint
            )
            // Right leg
            canvas.drawRoundRect(
                RectF(px + pw * 0.55f, py + ph * 0.75f,
                    px + pw * 0.75f, py + ph + legOffset2),
                6f, 6f, paint
            )
        }

        // Power-up glow overlay
        activePowerUp?.let { power ->
            val overlayColor = when (power) {
                PowerUpType.LIGHTNING_DASH -> Color.parseColor("#FFFF00")
                PowerUpType.SHIELD_PROTECTION -> Color.parseColor("#4FC3F7")
                PowerUpType.FIRE_TRAIL -> Color.parseColor("#FF6B00")
                PowerUpType.SHADOW_TELEPORT -> Color.parseColor("#CE93D8")
            }
            paint.color = overlayColor
            paint.alpha = (40 + glowPulse * 60f).toInt()
            canvas.drawRoundRect(
                RectF(px, py, px + pw, py + ph),
                10f, 10f, paint
            )
        }
    }

    private fun getSkinColors(): SkinColors {
        return when (PlayerDataManager.getActiveSkin()) {
            SkinId.NEON -> SkinColors(
                primaryColor = Color.parseColor("#00E5FF"),
                accentColor = Color.parseColor("#7C4DFF"),
                glowColor = Color.parseColor("#00BCD4"),
                eyeColor = Color.parseColor("#FFFFFF")
            )
            SkinId.FIRE -> SkinColors(
                primaryColor = Color.parseColor("#FF6D00"),
                accentColor = Color.parseColor("#FFAB40"),
                glowColor = Color.parseColor("#FF3D00"),
                eyeColor = Color.parseColor("#FFFF00")
            )
            SkinId.LEGENDARY -> SkinColors(
                primaryColor = Color.parseColor("#FFD700"),
                accentColor = Color.parseColor("#FFF9C4"),
                glowColor = Color.parseColor("#FF8F00"),
                eyeColor = Color.parseColor("#FFFFFF")
            )
            SkinId.CYBER -> SkinColors(
                primaryColor = Color.parseColor("#76FF03"),
                accentColor = Color.parseColor("#64FFDA"),
                glowColor = Color.parseColor("#00E676"),
                eyeColor = Color.parseColor("#FFFF00")
            )
            SkinId.SHADOW -> SkinColors(
                primaryColor = Color.parseColor("#311B92"),
                accentColor = Color.parseColor("#7B1FA2"),
                glowColor = Color.parseColor("#6200EA"),
                eyeColor = Color.parseColor("#EA80FC")
            )
            else -> SkinColors(  // DEFAULT
                primaryColor = Color.parseColor("#1A1A2E"),
                accentColor = Color.parseColor("#00FFFF"),
                glowColor = Color.parseColor("#0D47A1"),
                eyeColor = Color.parseColor("#00FFFF")
            )
        }
    }

    fun die() {
        isAlive = false
        particleSystem.emitDeathExplosion(x + width / 2f, y + height / 2f)
    }

    data class SkinColors(
        val primaryColor: Int,
        val accentColor: Int,
        val glowColor: Int,
        val eyeColor: Int
    )
}
