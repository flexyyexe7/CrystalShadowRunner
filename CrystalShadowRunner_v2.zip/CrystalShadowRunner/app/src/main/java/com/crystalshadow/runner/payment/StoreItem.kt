package com.crystalshadow.runner.payment

import com.crystalshadow.runner.AppConfig

enum class StoreItemType {
    CRYSTALS_100,
    CRYSTALS_500,
    CRYSTALS_1000,
    LEGENDARY_SKIN,
    REMOVE_ADS
}

data class StoreItem(
    val type: StoreItemType,
    val title: String,
    val description: String,
    val priceInPaise: Int,
    val priceDisplay: String,
    val iconEmoji: String,
    val crystalReward: Int = 0,
    val isPopular: Boolean = false
)

object StoreItemCatalog {
    val allItems = listOf(
        StoreItem(
            type = StoreItemType.CRYSTALS_100,
            title = "100 Crystals",
            description = "100 Glowing Crystals for Crystal Shadow Runner",
            priceInPaise = AppConfig.PRICE_100_CRYSTALS_PAISE,
            priceDisplay = "₹20",
            iconEmoji = "💎",
            crystalReward = 100
        ),
        StoreItem(
            type = StoreItemType.CRYSTALS_500,
            title = "500 Crystals",
            description = "500 Glowing Crystals - Best Value Pack",
            priceInPaise = AppConfig.PRICE_500_CRYSTALS_PAISE,
            priceDisplay = "₹79",
            iconEmoji = "💎",
            crystalReward = 500,
            isPopular = true
        ),
        StoreItem(
            type = StoreItemType.CRYSTALS_1000,
            title = "1000 Crystals",
            description = "1000 Glowing Crystals - Mega Pack",
            priceInPaise = AppConfig.PRICE_1000_CRYSTALS_PAISE,
            priceDisplay = "₹149",
            iconEmoji = "💎",
            crystalReward = 1000
        ),
        StoreItem(
            type = StoreItemType.LEGENDARY_SKIN,
            title = "Legendary Skin",
            description = "Exclusive Golden Legendary Ninja Skin",
            priceInPaise = AppConfig.PRICE_LEGENDARY_SKIN_PAISE,
            priceDisplay = "₹199",
            iconEmoji = "👑",
            crystalReward = 0
        ),
        StoreItem(
            type = StoreItemType.REMOVE_ADS,
            title = "Remove Ads",
            description = "Remove all ads forever - One time purchase",
            priceInPaise = AppConfig.PRICE_REMOVE_ADS_PAISE,
            priceDisplay = "₹99",
            iconEmoji = "🚫",
            crystalReward = 0
        )
    )
}
