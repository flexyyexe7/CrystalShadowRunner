package com.crystalshadow.runner.ui

import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.crystalshadow.runner.R
import com.crystalshadow.runner.data.PlayerDataManager
import com.crystalshadow.runner.utils.SoundManager

class SettingsActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        setContentView(R.layout.activity_settings)

        val switchSound     = findViewById<Switch>(R.id.switchSound)
        val switchMusic     = findViewById<Switch>(R.id.switchMusic)
        val switchVibration = findViewById<Switch>(R.id.switchVibration)
        val etPlayerName    = findViewById<EditText>(R.id.etPlayerName)
        val btnSaveName     = findViewById<Button>(R.id.btnSaveName)

        // Load saved settings
        switchSound.isChecked     = PlayerDataManager.isSoundEnabled()
        switchMusic.isChecked     = PlayerDataManager.isMusicEnabled()
        switchVibration.isChecked = PlayerDataManager.isVibrationEnabled()
        etPlayerName.setText(PlayerDataManager.getPlayerName())

        // Save on toggle
        switchSound.setOnCheckedChangeListener { _, on ->
            PlayerDataManager.setSoundEnabled(on)
        }
        switchMusic.setOnCheckedChangeListener { _, on ->
            PlayerDataManager.setMusicEnabled(on)
            if (on) SoundManager.resumeMusic() else SoundManager.pauseMusic()
        }
        switchVibration.setOnCheckedChangeListener { _, on ->
            PlayerDataManager.setVibrationEnabled(on)
        }

        btnSaveName.setOnClickListener {
            val name = etPlayerName.text.toString().trim()
            if (name.isNotEmpty()) {
                PlayerDataManager.setPlayerName(name)
                Toast.makeText(this, "Name saved!", Toast.LENGTH_SHORT).show()
            }
        }

        // Stats
        val tvStats = findViewById<TextView>(R.id.tvStats)
        tvStats.text = buildString {
            appendLine("🎮 Games Played: ${PlayerDataManager.getGamesPlayed()}")
            appendLine("🏆 High Score: ${PlayerDataManager.getHighScore()}")
            appendLine("💎 Total Crystals: ${PlayerDataManager.getCrystals()}")
        }

        findViewById<View>(R.id.btnBack).setOnClickListener {
            SoundManager.playClick(); finish()
        }
    }
}
