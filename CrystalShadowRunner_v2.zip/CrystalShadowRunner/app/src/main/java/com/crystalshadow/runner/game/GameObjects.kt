package com.crystalshadow.runner.game

import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import com.crystalshadow.runner.utils.NeonPaint
import com.crystalshadow.runner.utils.ParticleSystem
import kotlin.math.sin
import kotlin.random.Random

// ─────────────────────────────────────────────────────────────────
//  BASE GAME OBJECT
// ─────────────────────────────────────────────────────────────────

abstract class GameObject(
    var x: Float,
    var y: Float,
    val width: Float,
    val height: Float
) {
    var active = true
    val hitbox get() = RectF(x + 4f, y + 4f, x + width - 4f, y + height - 4f)

    open fun update(speed: Float) {
        x -= speed
        if (x + width < -100f) active = false
    }

    abstract fun draw(canvas: Canvas, paint: Paint, tick: Int)
}

// ─────────────────────────────────────────────────────────────────
//  OBSTACLE
// ─────────────────────────────────────────────────────────────────

class Obstacle(
    x: Float,
    y: Float,
    width: Float,
    height: Float,
    val type: ObstacleType,
    private val environment: NeonPaint.Environment
) : GameObject(x, y, width, height) {

    enum class ObstacleType {
        GROUND_SPIKE, TALL_WALL, FLOATING_PLATFORM, ELECTRIC_GATE, LASER_BEAM
    }

    override fun draw(canvas: Canvas, paint: Paint, tick: Int) {
        when (type) {
            ObstacleType.GROUND_SPIKE -> drawSpike(canvas, paint, tick)
            ObstacleType.TALL_WALL -> drawWall(canvas, paint, tick)
            ObstacleType.FLOATING_PLATFORM -> drawPlatform(canvas, paint, tick)
            ObstacleType.ELECTRIC_GATE -> drawElectricGate(canvas, paint, tick)
            ObstacleType.LASER_BEAM -> drawLaser(canvas, paint, tick)
        }
    }

    private fun drawSpike(canvas: Canvas, paint: Paint, tick: Int) {
        val spikeCount = (width / 20f).toInt().coerceAtLeast(1)
        paint.color = Color.parseColor("#FF4444")
        paint.style = Paint.Style.FILL
        for (i in 0 until spikeCount) {
            val sx = x + i * 20f
            val path = android.graphics.Path().apply {
                moveTo(sx, y + height)
                lineTo(sx + 10f, y)
                lineTo(sx + 20f, y + height)
                close()
            }
            canvas.drawPath(path, paint)
        }
        // Red glow
        paint.color = Color.parseColor("#FF0000")
        paint.alpha = 80
        paint.maskFilter = android.graphics.BlurMaskFilter(8f, android.graphics.BlurMaskFilter.Blur.NORMAL)
        canvas.drawRect(x - 4f, y - 4f, x + width + 4f, y + height, paint)
        paint.maskFilter = null
        paint.alpha = 255
    }

    private fun drawWall(canvas: Canvas, paint: Paint, tick: Int) {
        val wallColor = when (environment) {
            NeonPaint.Environment.CITY -> Color.parseColor("#37474F")
            NeonPaint.Environment.JUNGLE -> Color.parseColor("#1B5E20")
            NeonPaint.Environment.CYBER_NEON -> Color.parseColor("#1A0030")
        }
        val glowColor = when (environment) {
            NeonPaint.Environment.CITY -> Color.parseColor("#78909C")
            NeonPaint.Environment.JUNGLE -> Color.parseColor("#4CAF50")
            NeonPaint.Environment.CYBER_NEON -> Color.parseColor("#E040FB")
        }
        NeonPaint.drawNeonRect(
            canvas,
            RectF(x, y, x + width, y + height),
            wallColor, glowColor, 4f, 10f
        )
    }

    private fun drawPlatform(canvas: Canvas, paint: Paint, tick: Int) {
        NeonPaint.drawNeonRect(
            canvas,
            RectF(x, y, x + width, y + height),
            Color.parseColor("#1A237E"),
            Color.parseColor("#7986CB"),
            6f, 8f
        )
    }

    private fun drawElectricGate(canvas: Canvas, paint: Paint, tick: Int) {
        // Two posts
        paint.color = Color.parseColor("#455A64")
        paint.style = Paint.Style.FILL
        canvas.drawRect(x, y, x + 8f, y + height, paint)
        canvas.drawRect(x + width - 8f, y, x + width, y + height, paint)

        // Electric arc (flickering)
        val flickerAlpha = if (tick % 4 < 2) 255 else 180
        paint.color = Color.parseColor("#FFFF00")
        paint.alpha = flickerAlpha
        paint.strokeWidth = 3f
        paint.style = Paint.Style.STROKE
        paint.maskFilter = android.graphics.BlurMaskFilter(6f, android.graphics.BlurMaskFilter.Blur.NORMAL)

        // Draw zigzag electric arc
        val path = android.graphics.Path()
        path.moveTo(x + 8f, y + height / 2f)
        val segments = 6
        for (i in 1..segments) {
            val segX = x + 8f + (width - 16f) * i / segments
            val segY = y + height / 2f + (if (i % 2 == 0) -15f else 15f) * (tick % 3 + 1) * 0.3f
            path.lineTo(segX, segY)
        }
        canvas.drawPath(path, paint)
        paint.maskFilter = null
        paint.alpha = 255
    }

    private fun drawLaser(canvas: Canvas, paint: Paint, tick: Int) {
        val laserAlpha = if (tick % 6 < 3) 255 else 120
        paint.color = Color.parseColor("#FF1744")
        paint.alpha = laserAlpha
        paint.strokeWidth = 6f
        paint.style = Paint.Style.STROKE
        paint.maskFilter = android.graphics.BlurMaskFilter(10f, android.graphics.BlurMaskFilter.Blur.NORMAL)
        canvas.drawLine(x, y + height / 2f, x + width, y + height / 2f, paint)
        paint.maskFilter = null
        paint.alpha = 255
    }
}

// ─────────────────────────────────────────────────────────────────
//  COLLECTIBLE CRYSTAL
// ─────────────────────────────────────────────────────────────────

class Crystal(x: Float, y: Float) : GameObject(x, y, 24f, 24f) {

    private var floatOffset = 0f
    private var rotationAngle = 0f
    private var sparkle = 0f

    override fun update(speed: Float) {
        super.update(speed)
        floatOffset = (sin(System.currentTimeMillis() * 0.003).toFloat()) * 5f
        rotationAngle = (System.currentTimeMillis() * 0.1f) % 360f
        sparkle = (sin(System.currentTimeMillis() * 0.005).toFloat() * 0.5f + 0.5f)
    }

    override fun draw(canvas: Canvas, paint: Paint, tick: Int) {
        val drawY = y + floatOffset
        NeonPaint.drawCrystal(
            canvas,
            x + width / 2f,
            drawY + height / 2f,
            width / 2f + sparkle * 3f,
            (180 + sparkle * 75f).toInt()
        )
    }
}

// ─────────────────────────────────────────────────────────────────
//  POWER-UP ITEM
// ─────────────────────────────────────────────────────────────────

class PowerUpItem(
    x: Float,
    y: Float,
    val type: Player.PowerUpType
) : GameObject(x, y, 36f, 36f) {

    private var pulse = 0f
    private var rotation = 0f

    override fun update(speed: Float) {
        super.update(speed)
        pulse = (sin(System.currentTimeMillis() * 0.004).toFloat() * 0.5f + 0.5f)
        rotation += 2f
    }

    override fun draw(canvas: Canvas, paint: Paint, tick: Int) {
        val cx = x + width / 2f
        val cy = y + height / 2f
        val size = 14f + pulse * 4f

        val (innerColor, outerColor, icon) = when (type) {
            Player.PowerUpType.LIGHTNING_DASH ->
                Triple(Color.parseColor("#FFFF00"), Color.parseColor("#FF6F00"), "⚡")
            Player.PowerUpType.SHIELD_PROTECTION ->
                Triple(Color.parseColor("#4FC3F7"), Color.parseColor("#0288D1"), "🛡")
            Player.PowerUpType.FIRE_TRAIL ->
                Triple(Color.parseColor("#FF6B00"), Color.parseColor("#FF0000"), "🔥")
            Player.PowerUpType.SHADOW_TELEPORT ->
                Triple(Color.parseColor("#CE93D8"), Color.parseColor("#7B1FA2"), "👻")
        }

        // Background circle with glow
        paint.color = outerColor
        paint.style = Paint.Style.FILL
        paint.alpha = (100 + pulse * 80f).toInt()
        paint.maskFilter = android.graphics.BlurMaskFilter(size * 0.8f, android.graphics.BlurMaskFilter.Blur.NORMAL)
        canvas.drawCircle(cx, cy, size + 6f, paint)
        paint.maskFilter = null

        paint.color = innerColor
        paint.alpha = 220
        canvas.drawCircle(cx, cy, size, paint)

        NeonPaint.drawStarBurst(canvas, cx, cy, size * 0.4f, size * 0.85f, innerColor, 6, rotation)

        // Label
        NeonPaint.drawNeonText(
            canvas, icon, cx, cy + 5f,
            Color.WHITE, innerColor, 16f, 8f
        )
        paint.alpha = 255
    }
}

// ─────────────────────────────────────────────────────────────────
//  ENEMY
// ─────────────────────────────────────────────────────────────────

class Enemy(
    x: Float,
    y: Float,
    private val type: EnemyType = EnemyType.RUNNER
) : GameObject(x, y, 55f, 65f) {

    enum class EnemyType { RUNNER, FLYER, TURRET }

    private var animTick = 0
    private var baseY = y
    private var hp = 2
    val isDead get() = hp <= 0

    fun hit() { hp-- }

    override fun update(speed: Float) {
        x -= speed * 1.1f  // Enemies slightly faster than obstacles
        animTick++

        if (type == EnemyType.FLYER) {
            y = baseY + sin(animTick * 0.05).toFloat() * 30f
        }

        if (x + width < -100f) active = false
    }

    override fun draw(canvas: Canvas, paint: Paint, tick: Int) {
        if (isDead) return

        val pulse = (sin(tick * 0.15).toFloat() * 0.5f + 0.5f)

        when (type) {
            EnemyType.RUNNER -> drawRunnerEnemy(canvas, paint, pulse)
            EnemyType.FLYER -> drawFlyerEnemy(canvas, paint, pulse)
            EnemyType.TURRET -> drawTurretEnemy(canvas, paint, pulse)
        }
    }

    private fun drawRunnerEnemy(canvas: Canvas, paint: Paint, pulse: Float) {
        val color = Color.parseColor("#F44336")
        NeonPaint.drawNeonRect(
            canvas,
            RectF(x, y, x + width, y + height),
            Color.parseColor("#B71C1C"),
            color, 8f, 12f
        )
        // Red eyes
        paint.color = Color.parseColor("#FF1744")
        paint.alpha = (200 + pulse * 55f).toInt()
        paint.style = Paint.Style.FILL
        canvas.drawCircle(x + 14f, y + 18f, 5f, paint)
        canvas.drawCircle(x + 36f, y + 18f, 5f, paint)
        paint.alpha = 255
    }

    private fun drawFlyerEnemy(canvas: Canvas, paint: Paint, pulse: Float) {
        val color = Color.parseColor("#FF6F00")
        paint.color = color
        paint.style = Paint.Style.FILL
        paint.maskFilter = android.graphics.BlurMaskFilter(8f, android.graphics.BlurMaskFilter.Blur.NORMAL)
        canvas.drawOval(x, y + 10f, x + width, y + height - 10f, paint)
        paint.maskFilter = null

        // Wings
        val wingOffset = sin(animTick * 0.3).toFloat() * 8f
        paint.color = Color.parseColor("#FFAB40")
        paint.alpha = 200
        canvas.drawOval(x - 20f, y + wingOffset, x + 15f, y + 30f + wingOffset, paint)
        canvas.drawOval(x + width - 15f, y + wingOffset, x + width + 20f, y + 30f + wingOffset, paint)
        paint.alpha = 255
    }

    private fun drawTurretEnemy(canvas: Canvas, paint: Paint, pulse: Float) {
        NeonPaint.drawNeonRect(
            canvas,
            RectF(x, y + height * 0.3f, x + width, y + height),
            Color.parseColor("#37474F"),
            Color.parseColor("#78909C"), 4f, 8f
        )
        // Barrel
        paint.color = Color.parseColor("#607D8B")
        paint.style = Paint.Style.FILL
        canvas.drawRect(x - 20f, y + height * 0.4f, x + 10f, y + height * 0.6f, paint)
        // Warning light
        paint.color = Color.parseColor("#FF1744")
        paint.alpha = (150 + pulse * 100f).toInt().coerceIn(0, 255)
        canvas.drawCircle(x + width / 2f, y + height * 0.2f, 6f + pulse * 3f, paint)
        paint.alpha = 255
    }
}
