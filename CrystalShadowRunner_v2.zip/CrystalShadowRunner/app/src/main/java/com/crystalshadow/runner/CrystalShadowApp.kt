package com.crystalshadow.runner

import android.app.Application
import android.content.Context
import com.crystalshadow.runner.data.PlayerDataManager
import com.crystalshadow.runner.utils.SoundManager

/**
 * Application class — initializes global singletons.
 */
class CrystalShadowApp : Application() {

    companion object {
        lateinit var instance: CrystalShadowApp
            private set

        fun getContext(): Context = instance.applicationContext
    }

    override fun onCreate() {
        super.onCreate()
        instance = this

        // Initialize player data
        PlayerDataManager.init(this)

        // Pre-load sounds
        SoundManager.init(this)
    }

    override fun onTerminate() {
        super.onTerminate()
        SoundManager.release()
    }
}
