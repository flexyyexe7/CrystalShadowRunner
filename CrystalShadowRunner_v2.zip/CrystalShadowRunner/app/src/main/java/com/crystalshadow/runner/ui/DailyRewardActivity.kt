package com.crystalshadow.runner.ui

import android.os.Bundle
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.crystalshadow.runner.AppConfig
import com.crystalshadow.runner.R
import com.crystalshadow.runner.data.PlayerDataManager
import com.crystalshadow.runner.utils.SoundManager

class DailyRewardActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        setContentView(R.layout.activity_daily_reward)

        val day = (PlayerDataManager.getDailyRewardDay() % AppConfig.DAILY_REWARD_CRYSTALS.size)
        val reward = AppConfig.DAILY_REWARD_CRYSTALS[day]

        findViewById<TextView>(R.id.tvDayNumber).text = "Day ${day + 1}"
        findViewById<TextView>(R.id.tvRewardAmount).text = "+$reward 💎"
        findViewById<TextView>(R.id.tvStreak).text =
            "Login Streak: ${PlayerDataManager.getDailyRewardDay()} days"

        // Show all 7 days
        val dayLabels = listOf(
            R.id.tvDay1, R.id.tvDay2, R.id.tvDay3,
            R.id.tvDay4, R.id.tvDay5, R.id.tvDay6, R.id.tvDay7
        )
        dayLabels.forEachIndexed { index, id ->
            val tv = findViewById<TextView>(id)
            val amount = AppConfig.DAILY_REWARD_CRYSTALS[index]
            tv?.text = "${amount}💎"
            if (index < day) tv?.alpha = 0.4f     // claimed
            if (index == day) tv?.alpha = 1.0f    // today
        }

        findViewById<View>(R.id.btnClaimReward).setOnClickListener {
            SoundManager.playCrystalCollect()
            val earned = PlayerDataManager.claimDailyReward()
            val btn = it as? android.widget.Button
            btn?.text = "✓ Claimed!"
            btn?.isEnabled = false
            finish()
        }

        findViewById<View>(R.id.btnSkip).setOnClickListener { finish() }
    }
}
