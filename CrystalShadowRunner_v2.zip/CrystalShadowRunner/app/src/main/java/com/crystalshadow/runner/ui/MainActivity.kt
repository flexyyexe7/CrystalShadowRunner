package com.crystalshadow.runner.ui

import android.content.Intent
import android.graphics.*
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowManager
import android.view.animation.AnimationUtils
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.crystalshadow.runner.R
import com.crystalshadow.runner.data.PlayerDataManager
import com.crystalshadow.runner.store.StoreActivity
import com.crystalshadow.runner.utils.NeonPaint
import com.crystalshadow.runner.utils.ParticleSystem
import com.crystalshadow.runner.utils.SoundManager

class MainActivity : AppCompatActivity() {

    private lateinit var backgroundView: MainMenuBackground
    private val handler = Handler(Looper.getMainLooper())

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.setFlags(
            WindowManager.LayoutParams.FLAG_FULLSCREEN,
            WindowManager.LayoutParams.FLAG_FULLSCREEN
        )
        setContentView(R.layout.activity_main)

        // Animated background
        backgroundView = MainMenuBackground(this)
        val bgContainer = findViewById<FrameLayout>(R.id.bgContainer)
        bgContainer.addView(backgroundView, 0)

        setupButtons()
        updateCrystalDisplay()
        SoundManager.startBackgroundMusic(this)
    }

    private fun setupButtons() {
        findViewById<View>(R.id.btnPlay).setOnClickListener {
            SoundManager.playClick()
            startActivity(Intent(this, GameActivity::class.java))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        }

        findViewById<View>(R.id.btnStore).setOnClickListener {
            SoundManager.playClick()
            startActivity(Intent(this, StoreActivity::class.java))
        }

        findViewById<View>(R.id.btnLeaderboard).setOnClickListener {
            SoundManager.playClick()
            startActivity(Intent(this, LeaderboardActivity::class.java))
        }

        findViewById<View>(R.id.btnSettings).setOnClickListener {
            SoundManager.playClick()
            startActivity(Intent(this, SettingsActivity::class.java))
        }

        findViewById<View>(R.id.btnExit).setOnClickListener {
            SoundManager.playClick()
            finishAffinity()
        }
    }

    private fun updateCrystalDisplay() {
        val crystalText = findViewById<TextView>(R.id.tvCrystals)
        crystalText?.text = "💎 ${PlayerDataManager.getCrystals()}"
    }

    override fun onResume() {
        super.onResume()
        updateCrystalDisplay()
        SoundManager.resumeMusic()
    }

    override fun onPause() {
        super.onPause()
        SoundManager.pauseMusic()
    }
}

/** Animated neon background for the main menu */
class MainMenuBackground(context: android.content.Context) : View(context) {
    private val particles = ParticleSystem()
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var tick = 0f
    private val handler = Handler(Looper.getMainLooper())

    private val runnable = object : Runnable {
        override fun run() {
            tick++
            if (width > 0) {
                particles.emitAmbientDust(width.toFloat(), height.toFloat())
                if (tick.toInt() % 60 == 0)
                    particles.emitCrystalSparkle(
                        (Math.random() * width).toFloat(),
                        (Math.random() * height * 0.7f).toFloat()
                    )
            }
            particles.update()
            invalidate()
            handler.postDelayed(this, 16)
        }
    }

    init { handler.post(runnable) }

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        NeonPaint.drawBackground(canvas, w, h, NeonPaint.Environment.CYBER_NEON)

        // Stars
        paint.color = Color.WHITE
        for (i in 0..40) {
            val sx = (i * 137.5f * w * 0.01f) % w
            val sy = (i * 97.3f * h * 0.01f) % (h * 0.7f)
            val starAlpha = ((Math.sin(tick * 0.02 + i) * 0.5 + 0.5) * 150 + 50).toInt()
            paint.alpha = starAlpha
            canvas.drawCircle(sx, sy, 1.5f, paint)
        }

        particles.draw(canvas)
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        handler.removeCallbacks(runnable)
    }
}
