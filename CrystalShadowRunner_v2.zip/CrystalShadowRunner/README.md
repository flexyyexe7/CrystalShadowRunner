# 💎 Crystal Shadow Runner — Android Game

> Endless runner action game with neon visuals, power-ups, and Razorpay in-app purchases.

---

## 📁 Project Structure

```
CrystalShadowRunner/
├── app/
│   ├── src/main/
│   │   ├── java/com/crystalshadow/runner/
│   │   │   ├── AppConfig.kt              ← ⚠️ ADD YOUR KEYS HERE
│   │   │   ├── CrystalShadowApp.kt
│   │   │   ├── game/
│   │   │   │   ├── GameEngine.kt         ← Core game loop
│   │   │   │   ├── GameView.kt           ← SurfaceView + 60FPS renderer
│   │   │   │   ├── GameObjects.kt        ← Obstacles, crystals, enemies
│   │   │   │   └── Player.kt             ← Ninja player + power-ups
│   │   │   ├── ui/
│   │   │   │   ├── SplashActivity.kt
│   │   │   │   ├── MainActivity.kt
│   │   │   │   ├── GameActivity.kt
│   │   │   │   ├── GameOverActivity.kt
│   │   │   │   ├── LeaderboardActivity.kt
│   │   │   │   ├── SettingsActivity.kt
│   │   │   │   └── DailyRewardActivity.kt
│   │   │   ├── store/
│   │   │   │   └── StoreActivity.kt      ← Razorpay payments
│   │   │   ├── payment/
│   │   │   │   ├── RazorpayManager.kt    ← Payment logic
│   │   │   │   └── StoreItem.kt          ← Item catalog
│   │   │   ├── data/
│   │   │   │   ├── PlayerDataManager.kt  ← SharedPreferences
│   │   │   │   ├── AppDatabase.kt        ← Room DB
│   │   │   │   └── LeaderboardDao.kt
│   │   │   └── utils/
│   │   │       ├── NeonPaint.kt          ← Neon drawing utilities
│   │   │       ├── ParticleSystem.kt     ← Visual effects
│   │   │       └── SoundManager.kt       ← Audio
│   │   ├── res/
│   │   │   ├── layout/                   ← All XML layouts
│   │   │   ├── values/                   ← Colors, themes, strings
│   │   │   └── drawable/                 ← App icons
│   │   └── AndroidManifest.xml
│   ├── build.gradle
│   └── proguard-rules.pro
├── build.gradle
├── settings.gradle
└── gradle.properties
```

---

## 🚀 Setup Instructions (Step by Step)

### Step 1 — Open in Android Studio
1. Download and unzip `CrystalShadowRunner.zip`
2. Open **Android Studio** (Arctic Fox or newer)
3. Click **File → Open** → Select the `CrystalShadowRunner` folder
4. Wait for Gradle sync to complete

---

### Step 2 — Add Your Razorpay Key ⚠️ IMPORTANT

Open `app/src/main/java/com/crystalshadow/runner/AppConfig.kt`:

```kotlin
// REPLACE THIS with your actual Razorpay Key ID
const val RAZORPAY_KEY_ID = "rzp_test_REPLACE_WITH_YOUR_KEY"

// Your UPI ID
const val UPI_ID = "your-upi@paytm"
```

**How to get Razorpay Key:**
1. Go to https://dashboard.razorpay.com
2. Login → Settings → API Keys
3. Generate Key → Copy **Key ID** (starts with `rzp_test_` for testing)
4. Paste it in `AppConfig.kt`

> ⚠️ Use `rzp_test_` key for testing, `rzp_live_` for production.

---

### Step 3 — Change Crystal Prices (Optional)

In `AppConfig.kt`, prices are in **Paise** (1 INR = 100 Paise):

```kotlin
const val PRICE_100_CRYSTALS_PAISE  = 2000   // ₹20
const val PRICE_500_CRYSTALS_PAISE  = 7900   // ₹79
const val PRICE_1000_CRYSTALS_PAISE = 14900  // ₹149
const val PRICE_LEGENDARY_SKIN_PAISE = 19900 // ₹199
const val PRICE_REMOVE_ADS_PAISE    = 9900   // ₹99
```

---

### Step 4 — Add Sound Files (Optional)

Place these files in `app/src/main/res/raw/`:
- `jump.mp3`
- `crystal_collect.mp3`
- `power_up.mp3`
- `game_over.mp3`
- `bg_cyber_music.mp3`

Then uncomment the sound loading lines in `SoundManager.kt`.

---

### Step 5 — Build & Run APK

**For Testing (Debug APK):**
```
Build → Build Bundle(s) / APK(s) → Build APK(s)
```
APK location: `app/build/outputs/apk/debug/app-debug.apk`

**For Release (Signed APK):**
```
Build → Generate Signed Bundle / APK
→ APK → Create new keystore → Fill details → Build
```

---

## 💳 Payment Flow (How Razorpay Works)

```
User taps "Buy 500 Crystals ₹79"
        ↓
Confirmation dialog appears
        ↓
Razorpay Checkout popup opens
(UPI / Card / Netbanking / Wallet)
        ↓
User pays
        ↓
onPaymentSuccess() called in StoreActivity
        ↓
RazorpayManager.handlePaymentSuccess() called
        ↓
500 crystals added to player wallet instantly
        ↓
Success dialog shown ✅
```

**On failure:**
```
onPaymentError() called → "Payment Failed. Please try again." shown
```

---

## 🎮 Game Controls

| Action | Gesture |
|--------|---------|
| Jump | Tap screen |
| Double Jump | Tap again while in air |
| Slide | Swipe down |
| Dash | Swipe right |

---

## ⚡ Power-ups

| Power-up | Effect | Duration |
|----------|--------|----------|
| ⚡ Lightning Dash | Speed boost + kills enemies | 3 sec |
| 🛡 Shield | Invincible to obstacles | 5 sec |
| 🔥 Fire Trail | Fire particles + kills enemies | 4 sec |
| 👻 Shadow Teleport | Phase through obstacles | 2 sec |

---

## 🔧 Config Options in AppConfig.kt

| Setting | Description |
|---------|-------------|
| `GAME_SPEED_INITIAL` | Starting speed of the game |
| `GAME_SPEED_MAX` | Maximum speed cap |
| `GRAVITY` | How fast player falls |
| `JUMP_FORCE` | How high player jumps |
| `STARTING_CRYSTALS` | Crystals given on first install |
| `DEBUG_GOD_MODE` | Set `true` to never die (testing) |
| `DEBUG_SHOW_FPS` | Show FPS counter |

---

## 📦 Dependencies Used

| Library | Purpose |
|---------|---------|
| `com.razorpay:checkout:1.6.38` | Payment gateway |
| `androidx.room` | Local leaderboard database |
| `kotlinx.coroutines` | Async operations |
| `com.google.android.material` | Neon UI components |

---

## 🛠 Minimum Requirements

- Android 5.0 (API 21) and above
- Works on low-end devices (optimized Canvas 2D renderer)
- Internet permission required for Razorpay

---

## 📞 Razorpay Support

- Docs: https://razorpay.com/docs/payment-gateway/android-integration/
- Dashboard: https://dashboard.razorpay.com
- Test Cards: https://razorpay.com/docs/payments/payments/test-card-details/

---

*Crystal Shadow Runner v1.0.0 — Built with Kotlin + Android Canvas 2D*
